In this folder there are no more binaries since they depends on the LIBCC version.
To build them open a terminal and just type make