# Mtrigen-modbus
A modbus network to read PLC parameter
