# ModbusTool
A modbus master and slave test tool with import and export functionality, supports TCP, UDP and RTU.


