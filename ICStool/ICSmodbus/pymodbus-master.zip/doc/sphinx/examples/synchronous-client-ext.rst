==================================================
Synchronous Client Extended Example
==================================================

.. literalinclude:: ../../../examples/common/synchronous-client-ext.py

