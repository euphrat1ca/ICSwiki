==================================================
Custom Message Example
==================================================

.. literalinclude:: ../../../examples/common/custom-message.py

