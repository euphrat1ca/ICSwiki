# PyCIP
Common Industrial Protocol (CIP) for Python3

Allows Communiction as Originator to Target devices using the CIP protocol over EtherNet/IP

see CIP_Demo.py for example on how to use

see wiki for core componets documentation

