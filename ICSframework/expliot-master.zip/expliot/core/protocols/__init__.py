"""Communication protocols for EXPLIoT."""
