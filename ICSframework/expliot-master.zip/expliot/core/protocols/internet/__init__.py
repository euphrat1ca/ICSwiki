"""Support for various protocols usually used in public networks."""
