"""Support for SPI."""

from expliot.core.interfaces.ftdi import SpiFlashManager
