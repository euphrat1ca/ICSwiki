"""Wrapper for the i2c communication."""

from expliot.core.interfaces.ftdi import I2cEepromManager
