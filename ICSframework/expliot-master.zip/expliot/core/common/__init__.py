"""Common helpers for EXPLIoT."""
