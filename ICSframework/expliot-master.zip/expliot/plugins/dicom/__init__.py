"""Support for DICOM."""
REFERENCE = "https://www.dicomstandard.org/current/"
