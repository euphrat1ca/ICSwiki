"""Support for communicating over i2c."""
