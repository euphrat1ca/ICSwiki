"""Support for CoAP interactions."""
