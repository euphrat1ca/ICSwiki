"""Support for Bluetooth LE test."""
