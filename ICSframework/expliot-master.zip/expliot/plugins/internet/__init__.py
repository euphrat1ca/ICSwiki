"""Plugin for connected devices."""
