"""Plugin/test for MQTT."""
DEFAULT_MQTT_PORT = 1883

MQTT_REFERENCE = "http://docs.oasis-open.org/mqtt/mqtt/v3.1.1/mqtt-v3.1.1.html"
