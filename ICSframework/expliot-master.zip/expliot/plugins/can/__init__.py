"""Support for interaction with a CAN bus."""
