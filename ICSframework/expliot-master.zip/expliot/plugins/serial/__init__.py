"""Support for serial communication."""
