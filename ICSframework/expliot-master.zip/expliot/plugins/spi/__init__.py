"""Support for SPI communication."""
