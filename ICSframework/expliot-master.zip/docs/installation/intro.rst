Installation
============

There are multiple options available to install EXPLIoT.

Available installation methods
------------------------------

.. toctree::
    :maxdepth: 1
    :glob:

    **
