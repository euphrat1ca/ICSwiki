User Guide
==========

Great! You have successfully installed EXPLIoT Framework. Now what?
To use the framework as a tool you can run the command line utility
``expliot``.

There are two ways to run ``expliot``:


- :ref:`Command line mode <command-line-mode>`
- :ref:`Interactive mode <interactive-mode>`

You can use whatever mode suits your requirements.


.. toctree::
    :maxdepth: 1
    :glob:

    **