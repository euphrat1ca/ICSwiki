UDP
===

As of now all, UDP based proprietary communication will be grouped here.
Eventually, it will be changed to something else.

udp.kankun.hijack
-----------------

This is an exploit for a Smart plug called Kankun, manufactured by a Chinese
vendor ikonke.com. It is out of production now.

**Usage details:**

.. code-block:: console

   ef> run udp.kankun.hijack -h
