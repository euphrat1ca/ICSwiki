#!/usr/bin/env python
# -*- coding:utf-8 -*-

"""
Copyright (c) 2014-2016 By W.HHH. All rights reserved.
See the file 'docs/COPYING' for copying permission
"""


import struct
from scapy.all import *
from tptk import *
from cotp import *
from s7comm import *

