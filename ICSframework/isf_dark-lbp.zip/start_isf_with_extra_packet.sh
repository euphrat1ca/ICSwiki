#!/usr/bin/env bash
export extra_package_path="./extra_isf_package"

python ./isf.py -e $extra_package_path
