#! /usr/bin/env python
# coding:utf-8
# Author: WenZhe Zhu
from icssploit.core.base import Base
from extra_protocols.s7comm import *
from scapy.supersocket import StreamSocket


class S7Client(Base):
    def __init__(self, name, ip, port=102, src_tsap='\x01\x00', slot=2, timeout=2):
        '''

        :param name: Name of this targets
        :param ip: S7 PLC ip
        :param port: S7 PLC port (default: 102)
        :param src_tsap: src_tsap
        :param slot: cpu slot (default: 2)
        :param timeout: timeout of socket (default: 2)
        '''
        super(S7Client, self).__init__(name=name)
        self._ip = ip
        self._port = port
        self._slot = slot
        self._src_tsap = src_tsap
        self._dst_tsap = '\x01' + struct.pack('B', slot)
        self._pdur = 1
        self._protect_level = None
        self._connection = None
        self._connected = False
        self._timeout = timeout
        self._pdu_length = 480
        self._readable = False
        self._writeable = False
        self._authorized = False
        self._password = None
        self._mmc_password = None
        self._is_running = False

    def connect(self):
        sock = socket.socket()
        sock.connect((self._ip, self._port))
        sock.settimeout(self._timeout)
        self._connection = StreamSocket(sock, Raw)
        packet1 = TpktReq() / CotpCr()
        packet1.Parameters = [CotpOption() for i in range(3)]
        packet1.PDUType = "CR"
        packet1.Parameters[0].ParameterCode = "tpdu-size"
        packet1.Parameters[0].Parameter = "\x0a"
        packet1.Parameters[1].ParameterCode = "src-tsap"
        packet1.Parameters[2].ParameterCode = "dst-tsap"
        packet1.Parameters[1].Parameter = self._src_tsap
        packet1.Parameters[2].Parameter = self._dst_tsap
        self.send_receive_packet(packet1)
        packet2 = TpktReq() / CotpDtReq(EOT=1) / S7SetConReq()
        rsp2 = self.send_receive_s7_packet(packet2)
        if rsp2:
            self._connected = True
        # Todo: Need get pdu length from rsp2

    def _get_cpu_protect_level(self):
        packet1 = TpktReq() / CotpDtReq(EOT=1) / S7ReadSZLReq()
        packet1[S7ReadSZLDataReq].SZLId = 0x0232
        packet1[S7ReadSZLDataReq].SZLIndex = 0x0004
        rsp = self.send_receive_s7_packet(packet1)
        self._protect_level = int(str(rsp)[48].encode('hex'))
        self.logger.info("CPU protect level is %s" % self._protect_level)

    def check_privilege(self):
        self._get_cpu_protect_level()
        if self._protect_level == 1:
            self.logger.info("You have full privilege with this targets")
            self._readable = True
            self._writeable = True
        if self._protect_level == 2:
            if self._authorized is True:
                self.logger.info("You have full privilege with this targets")
                self._readable = True
                self._writeable = True
            else:
                self.logger.info("You only have read privilege with this targets")
                self._readable = True
                self._writeable = False
        if self._protect_level == 3:
            if self._authorized is True:
                self.logger.info("You have full privilege with this targets")
                self._readable = True
                self._writeable = True
            else:
                self.logger.info("You can't read or write with this targets")
                self._readable = False
                self._writeable = False

    def auth(self, password):
        self.logger.info("Start authenticate with password %s" % password)
        password_hash = self._hash_password(password)
        packet1 = TpktReq() / CotpDtReq(EOT=1) / S7PasswordReq()
        packet1.Data.Data = password_hash
        rsp1 = self.send_receive_s7_packet(packet1)
        if str(rsp1)[-6:-4] == '\x00\x00':
            self._authorized = True
            self.logger.info("Authentication succeed")
        else:
            if self._authorized is True:
                self.logger.info("Already authorized")
            else:
                self.logger.info("Authentication failure")
        self.check_privilege()

    def clean_session(self):
        self.logger.info("Start clean the session")
        packet1 = TpktReq() / CotpDtReq(EOT=1) / S7CleanSessionReq()
        self.send_receive_s7_packet(packet1)
        self._authorized = False

    def _hash_password(self, password):
        password_hash_new = ''
        if len(password) < 1 or len(password) > 8:
            self.logger.error("Password length must between 1 to 8")
            return None
        else:
            password += '20'.decode('hex') * (8 - len(password))
            for i in range(8):
                if i < 2:
                    temp_data = ord(password[i])
                    temp_data ^= 0x55
                    password_hash_new += str(chr(temp_data))
                else:
                    temp_data1 = ord(password[i])
                    temp_data2 = ord(password_hash_new[i - 2])
                    temp_data1 = temp_data1 ^ 0x55 ^ temp_data2
                    password_hash_new += str(chr(temp_data1))
            return password_hash_new


    @staticmethod
    def _dehash_password(pass_hash):
        password = ''
        password_hash = pass_hash
        for i in range(8):
            if i < 2:
                temp_data = ord(password_hash[i])
                temp_data ^= 0x55
                password += str(unichr(temp_data))
            else:
                temp_data1 = ord(password_hash[i])
                temp_data2 = ord(pass_hash[i - 2])
                temp_data1 = temp_data1 ^ temp_data2 ^ 0x55
                password += str(unichr(temp_data1))
        for i in range(8):
            if password[-1] == ' ':
                password = password[: -1]
        return password

    def _fix_pdur(self, payload):
        if self._pdur > 65535:
            self._pdur = 1
        try:
            payload.PDUR = self._pdur
            self._pdur += 1
            return payload
        except Exception as err:
            self.logger.error(err)
            return payload

    def send_packet(self, packet):
        if self._connection:
            try:
                self._connection.send(packet)

            except Exception as err:
                self.logger.error(err)
                return None

        else:
            self.logger.error("Please create connect before send packet!")

    def send_receive_packet(self, packet):
        if self._connection:
            try:
                rsp = self._connection.sr1(packet, timeout=self._timeout)
                return rsp

            except Exception as err:
                self.logger.error(err)
                return None

        else:
            self.logger.error("Please create connect before send packet!")

    def receive_packet(self):
        if self._connection:
            try:
                rsp = self._connection.recv()
                return rsp

            except Exception as err:
                self.logger.error(err)
                return None

        else:
            self.logger.error("Please create connect before receive packet!")

    def send_s7_packet(self, packet):
        if self._connection:
            packet = self._fix_pdur(packet)
            try:
                self._connection.send(packet)

            except Exception as err:
                self.logger.error(err)
                return None

        else:
            self.logger.error("Please create connect before send packet!")

    def send_receive_s7_packet(self, packet):
        if self._connection:
            packet = self._fix_pdur(packet)
            try:
                rsp = self._connection.sr1(packet, timeout=self._timeout)
                if rsp:
                    rsp = TpktRsp(str(rsp))
                return rsp

            except Exception as err:
                self.logger.error(err)
                return None

        else:
            self.logger.error("Please create connect before send packet!")

    def receive_s7_packet(self):
        if self._connection:
            try:
                rsp = self._connection.recv()
                if rsp:
                    rsp = TpktRsp(str(rsp))
                return rsp

            except Exception as err:
                self.logger.error(err)
                return None
        else:
            self.logger.error("Please create connect before receive packet!")

    def upload_block_from_target(self, block_type, block_num):
        '''

        :param block_type: {0x38: "OB", 0x41: "DB", 0x42: "SDB", 0x43: "FC", 0x44: "SFC", 0x45: "FB", 0x46: "SFB"}
        :param block_num:
        :return: Block Data
        '''
        if self._readable is False:
            self.logger.info("Didn't have read privilege on targets")
            return None
        block_data = ''
        self.logger.info("Start upload %s%s from targets" % (block_type, block_num))
        packet1 = TpktReq() / CotpDtReq(EOT=1) / S7RequestUploadBlockReq()
        packet1.Parameters.BlockType = block_type
        # Todo: Need find a better way to do this.
        packet1.Parameters.BlockNum = '0' * (5 - len(str(block_num))) + str(block_num)
        rsp1 = self.send_receive_s7_packet(packet1)
        # Todo: Might got some error
        if rsp1.ErrorClass != 0x0:
            self.logger.error("Can't upload %s%s from targets" % (block_type, block_num))
            self.logger.error("Error Class: %s, Error Code %s" % (rsp1.ErrorClass, rsp1.ErrorCode))
            return None
        packet2 = TpktReq() / CotpDtReq(EOT=1) / S7UploadBlockReq()
        packet2[S7UploadBlockParameterReq].UploadId=rsp1[S7RequestUploadBlockParameterRsp].UploadId
        while True:
            rsp2 = self.send_receive_s7_packet(packet2)
            if rsp2.ErrorClass != 0x0:
                self.logger.error("Can't upload %s%s from targets" % (block_type, block_num))
                self.logger.error("Error Class: %s, Error Code %s" % (rsp1.ErrorClass, rsp1.ErrorCode))
                return None
            self.logger.debug("rsp2: %s" % str(rsp2).encode('hex'))
            block_data += rsp2.Data.Data
            if rsp2.Parameters.FunctionStatus != 1:
                break
        packet3 = TpktReq() / CotpDtReq(EOT=1) / S7UploadBlockEndReq()
        self.send_receive_s7_packet(packet3)
        return block_data

    def get_info_from_block(self, block_data):
        try:
            mem_length = struct.unpack('!i', block_data[8:12])[0]
            mc7_length = struct.unpack('!h', block_data[34:36])[0]
            block_type = S7_Block_Type_In_Block[ord(block_data[5])]
            block_num = struct.unpack('!h', block_data[6:8])[0]
            return mem_length, mc7_length, block_type, block_num

        except Exception as err:
            self.logger.error(err)
            return None

    def download_block_to_target(self, block_data, transfer_size=462, stop_target=False):
        if self._writeable is False:
            self.logger.info("Didn't have write privilege on targets")
            return None
        mem_length, mc7_length, block_type, block_num = self.get_info_from_block(block_data)
        self.logger.info("Start download %s%s to targets" % (block_type, block_num))
        packet1 = TpktReq() / CotpDtReq(EOT=1) / S7RequestDownloadBlockReq()
        packet1.Parameters.BlockType = block_type
        packet1.Parameters.BlockNum = '0' * (5 - len(str(block_num))) + str(block_num)
        packet1.Parameters.LoadMemLength = '0' * (6 - len(str(mem_length))) + str(mem_length)
        packet1.Parameters.MC7Length = '0' * (6 - len(str(mc7_length))) + str(mc7_length)
        rsp1 = self.send_receive_s7_packet(packet1)
        # rsp1.show()
        # Todo: Might got some error
        if rsp1.ErrorClass != 0x0:
            self.logger.error("Can't Download %s%s to targets" % (block_type, block_num))
            self.logger.error("Error Class: %s, Error Code %s" % (rsp1.ErrorClass, rsp1.ErrorCode))
            return None
        download_req = self.receive_s7_packet()
        # Get pdur from download_req
        self._pdur = struct.unpack('!h', str(download_req)[11:13])[0]
        # DownloadBlock
        for i in range(0, len(block_data), transfer_size):
            if i + transfer_size <= len(block_data):
                packet2 = TpktReq() / CotpDtReq(EOT=1) / S7DownloadBlockRsp()
                packet2.Parameters.FunctionStatus = 1
                packet2.Data.Data = block_data[i:i + transfer_size]
                rsp2 = self.send_receive_s7_packet(packet2)
                self._pdur = struct.unpack('!h', str(rsp2)[11:13])[0]
            else:
                packet2 = TpktReq() / CotpDtReq(EOT=1) / S7DownloadBlockRsp()
                packet2.Parameters.FunctionStatus = 0
                packet2.Data.Data = block_data[i:i + transfer_size]
                self.send_s7_packet(packet2)
        # DownloadBlockEnd
        download_end_req = self.receive_s7_packet()
        self._pdur = struct.unpack('!h', str(download_end_req)[11:13])[0]
        packet3 = TpktReq() / CotpDtReq(EOT=1) / S7DownloadBlockEndRsp()
        self.send_s7_packet(packet3)

        packet4 = TpktReq() / CotpDtReq(EOT=1) / S7PIServiceReq()
        # Todo: Might have a better way to do this
        block_type_value = S7_Block_Type.keys()[S7_Block_Type.values().index(block_type)]
        parameter_block = '\x01\x00\x30' + chr(block_type_value) + ('0' * (5 - len(str(block_num))) + str(block_num)) + 'P'
        packet4.Parameters.ParameterBlock = parameter_block
        packet4.Parameters.PI = "_INSE"
        rsp4 = self.send_receive_s7_packet(packet4)
        if rsp4.ErrorClass != 0x0:
            self.logger.error("Can't insert %s%s to targets" % (block_type, block_num))
            self.logger.error("Error Class: %s, Error Code %s" % (rsp1.ErrorClass, rsp1.ErrorCode))
            return None

    def download_block_to_target_only(self, block_data, transfer_size=462, stop_target=False):
        if self._writeable is False:
            self.logger.info("Didn't have write privilege on targets")
            return None
        mem_length, mc7_length, block_type, block_num = self.get_info_from_block(block_data)
        self.logger.info("Start download %s%s to targets" % (block_type, block_num))
        packet1 = TpktReq() / CotpDtReq(EOT=1) / S7RequestDownloadBlockReq()
        packet1.Parameters.BlockType = block_type
        packet1.Parameters.BlockNum = '0' * (5 - len(str(block_num))) + str(block_num)
        packet1.Parameters.LoadMemLength = '0' * (6 - len(str(mem_length))) + str(mem_length)
        packet1.Parameters.MC7Length = '0' * (6 - len(str(mc7_length))) + str(mc7_length)
        rsp1 = self.send_receive_s7_packet(packet1)
        # rsp1.show()
        # Todo: Might got some error
        if rsp1.ErrorClass != 0x0:
            self.logger.error("Can't Download %s%s to targets" % (block_type, block_num))
            self.logger.error("Error Class: %s, Error Code %s" % (rsp1.ErrorClass, rsp1.ErrorCode))
            return None
        download_req = self.receive_s7_packet()
        # Get pdur from download_req
        self._pdur = struct.unpack('!h', str(download_req)[11:13])[0]
        # DownloadBlock
        for i in range(0, len(block_data), transfer_size):
            if i + transfer_size <= len(block_data):
                packet2 = TpktReq() / CotpDtReq(EOT=1) / S7DownloadBlockRsp()
                packet2.Parameters.FunctionStatus = 1
                packet2.Data.Data = block_data[i:i + transfer_size]
                rsp2 = self.send_receive_s7_packet(packet2)
                self._pdur = struct.unpack('!h', str(rsp2)[11:13])[0]
            else:
                packet2 = TpktReq() / CotpDtReq(EOT=1) / S7DownloadBlockRsp()
                packet2.Parameters.FunctionStatus = 0
                packet2.Data.Data = block_data[i:i + transfer_size]
                self.send_s7_packet(packet2)
        # DownloadBlockEnd
        download_end_req = self.receive_s7_packet()
        self._pdur = struct.unpack('!h', str(download_end_req)[11:13])[0]
        packet3 = TpktReq() / CotpDtReq(EOT=1) / S7DownloadBlockEndRsp()
        self.send_s7_packet(packet3)

    def download_file_to_target_only(self, file_name, file_data, transfer_size=462, stop_target=False):
        if self._writeable is False:
            self.logger.info("Didn't have write privilege on targets")
            return None
        self.logger.info("Start download %s to targets" % file_name)
        packet1 = TpktReq() / CotpDtReq(EOT=1) / S7RequestDownloadFileReq()
        packet1.Parameters.Filename = file_name
        rsp1 = self.send_receive_s7_packet(packet1)
        # rsp1.show()
        # Todo: Might got some error
        if rsp1.ErrorClass != 0x0:
            self.logger.error("Can't Download %s to targets" % file_name)
            self.logger.error("Error Class: %s, Error Code %s" % (rsp1.ErrorClass, rsp1.ErrorCode))
            return None
        download_req = self.receive_s7_packet()
        # Get pdur from download_req
        self._pdur = struct.unpack('!h', str(download_req)[11:13])[0]
        # DownloadBlock
        for i in range(0, len(file_data), transfer_size):
            if i + transfer_size <= len(file_data):
                packet2 = TpktReq() / CotpDtReq(EOT=1) / S7DownloadFileRsp()
                packet2.Parameters.FunctionStatus = 1
                packet2.Data.Data = file_data[i:i + transfer_size]
                rsp2 = self.send_receive_s7_packet(packet2)
                self._pdur = struct.unpack('!h', str(rsp2)[11:13])[0]
            else:
                packet2 = TpktReq() / CotpDtReq(EOT=1) / S7DownloadFileRsp()
                packet2.Parameters.FunctionStatus = 0
                packet2.Data.Data = file_data[i:i + transfer_size]
                self.send_s7_packet(packet2)
        # DownloadBlockEnd
        download_end_req = self.receive_s7_packet()
        self._pdur = struct.unpack('!h', str(download_end_req)[11:13])[0]
        packet3 = TpktReq() / CotpDtReq(EOT=1) / S7DownloadFileEndRsp()
        self.send_s7_packet(packet3)

    def get_target_status(self):
        packet1 = TpktReq() / CotpDtReq(EOT=1) / S7ReadSZLReq()
        packet1[S7ReadSZLDataReq].SZLId = 0x0424
        packet1[S7ReadSZLDataReq].SZLIndex = 0x0000
        rsp = self.send_receive_s7_packet(packet1)
        status = str(rsp)[44]
        if status == '\x08':
            self.logger.info("Target is in run mode")
            self._is_running = True
        elif status == '\x04':
            self.logger.info("Target is in stop mode")
            self._is_running = False
        else:
            self.logger.info("Target is in unknown mode")
            self._is_running = False

    def stop_target(self):
        self.get_target_status()
        if not self._is_running:
            self.logger.info("Target is already stop")
            return
        self.logger.info("Trying to stop targets")
        packet1 = TpktReq() / CotpDtReq(EOT=1) / S7StopCpuReq()
        rsp1 = self.send_receive_s7_packet(packet1)
        if rsp1.ErrorClass != 0x0:
            self.logger.error("Can't Stop Target")
            self.logger.error("Error Class: %s, Error Code %s" % (rsp1.ErrorClass, rsp1.ErrorCode))
            return
        time.sleep(2)  # wait targets to stop
        self.get_target_status()

    def start_target(self, cold=False):
        self.get_target_status()
        if self._is_running:
            self.logger.info("Target is already running")
            return
        self.logger.info("Trying to start targets")
        packet1 = TpktReq() / CotpDtReq(EOT=1) / S7PIServiceReq()
        if cold:
            packet1.Parameters.ParameterBlock = "C "
        rsp1 = self.send_receive_s7_packet(packet1)
        if rsp1.ErrorClass != 0x0:
            self.logger.error("Can't Start Target")
            self.logger.error("Error Class: %s, Error Code %s" % (rsp1.ErrorClass, rsp1.ErrorCode))
            return
        time.sleep(2)  # wait targets to start
        self.get_target_status()

    @staticmethod
    def _find_network_count_offset(block_data):
        '''

        :param block_data: block_data
        :return: first network_count offset of this block
        '''
        for i in range(len(block_data)):
            temp_data = block_data[i: i + 1]
            if temp_data == '\x20':
                return i
        return None

    def inject_code_to_block(self, src_block, mc7_code):
        '''

        :param src_block: Src block data
        :param mc7_code: Mc7 code to inject
        :return: New block with code injected
        '''
        new_block = src_block[:36] + mc7_code + src_block[36:]
        network_count_offset = self._find_network_count_offset(new_block)
        # fix network1_length
        network1_length_offset = network_count_offset + 2
        network1_length = struct.unpack('!H', new_block[network1_length_offset: network1_length_offset + 2])[0]
        network1_length += len(mc7_code)
        network1_length = struct.pack('!H', network1_length)
        new_block = new_block[: network1_length_offset] + network1_length + new_block[network1_length_offset + 2:]
        # fix mem_lenth and mc7_lenth
        new_mem_lenth = len(new_block)
        src_mc7_lenth = struct.unpack('!h', src_block[34: 36])[0]
        new_mc7_lenth = src_mc7_lenth + len(mc7_code)
        new_block = new_block[: 8] + struct.pack('!i', new_mem_lenth) + new_block[12:]
        new_block = new_block[: 34] + struct.pack('!h', new_mc7_lenth) + new_block[36:]
        # Todo: Need fix checksum in future
        return new_block
