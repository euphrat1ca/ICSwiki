#! /usr/bin/env python
# coding:utf-8
# Author: WenZhe Zhu
from scapy.all import conf
from scapy.packet import *
from scapy.fields import *
from scapy.layers.inet import TCP


S7_BlockLang_Type = {
    0x00: "Not defined",
    0x01: "AWL",
    0x02: "KOP",
    0x03: "FUP",
    0x04: "SCL",
    0x05: "DB",
    0x06: "GRAPH",
    0x07: "SDB",
    0x08: "CPU-DB",
    0x11: "SDB (after overall reset)",
    0x12: "KOP",
    0x29: "ENCRYPT"
}

S7_Block_Type = {
    0x38: "OB",
    0x41: "DB",
    0x42: "SDB",
    0x43: "FC",
    0x44: "SFC",
    0x45: "FB",
    0x46: "SFB"
}

S7_AREA_Type = {
    0x03: "SYSInfo",        # System info of 200 family
    0x05: "SYSFlags",       # System flags of 200 family
    0x06: "ANAIn",          # Analog inputs of 200 family
    0x07: "ANAOut",         # Analog outputs of 200 family
    0x80: "P",              # Direct peripheral access
    0x81: "Input",
    0x82: "Output",
    0x83: "Flags",
    0x84: "DB",             # Data blocks
    0x85: "DI",             # Instance data blocks
    0x86: "Local",          # Local data (should not be accessible over network) */
    0x87: "V",              # Previous (Vorgaenger) local data (should not be accessible over network)
    0x1C: "Counter",        # S7 counters
    0x1D: "Timer",          # S7 timers
    0x1E: "Counter200",     # IEC counters (200 family)
    0x1F: "Timer200"        # IEC timers (200 family)
}

S7_PDU_Type = {0x01: "JOB", 0x02: "Ack", 0x03: "Ack_Data", 0x07: "UserData"}

S7_Error_Class = {0x01: "No Error"}

S7_Return_Code = {
    0x00: "Reserved (0x00)",
    0x0a: "Object does not exist (0x0a)",
    0xff: "success (0xff)"
}

S7_Transport_Size = {
    0x00: "Null (0x00)",                #
    0x02: "Byte (0x02)",                # Byte access, len is in bits
    0x03: "Bit (0x03)",                 # Bit access, len is in bits
    0x04: "BYTE/WORD/DWORD (0x04)",     # BYTE/WORD/DWORD access, len is in bits
    0x05: "Int (0x05)",                 # Integer access, len is in bits
    0x07: "Real (0x07)",                # Real access, len is in bytes
    0x09: "Str (0x09)"                  # Octet string, len is in bytes
}

S7_UD_Function_Group = {
    0x0: "Mode-transition",
    0x1: "Programmer commands",
    0x2: "Cyclic data",
    0x3: "Block functions",
    0x4: "CPU functions",
    0x5: "Security",
    0x6: "PBC BSEND/BRECV",
    0x7: "Time functions",
    0xf: "NC programming"
}

S7_UD_Parameter_Type = {
    0x0: "Push",
    0x4: "Request",
    0x8: "Response",
    0x3: "NC Push",                     # used only by Sinumerik NC
    0x7: "NC Request",                  # used only by Sinumerik NC
    0xb: "NC Response",                 # used only by Sinumerik NC
}

S7_UD_SubFunction_Sec = {
    0x01: "PLC password"
}

S7_UD_SubFunction_Time = {
    0x01: "Read clock",
    0x02: "Set clock",
    0x03: "Read clock (following)",
    0x04: "Set clock"

}

S7_JB_Function = {
    0x00: "CPU services (0x00)",
    0x04: "Read Var (0x04)",
    0x05: "Write Var (0x05)",
    0x1a: "Request download (0x1a)",
    0x1b: "Download block (0x1b)",
    0x1c: "Download ended (0x1c)",
    0x1d: "Start upload (0x1d)",
    0x1e: "Upload (0x1e)",
    0x1f: "End upload (0x1f)",
    0x28: "PI-Service (0x28)",
    0x29: "PLC Stop (0x29)",
    0xf0: "Setup communication (0xf0)"
}

CotpParameterCode = {0xc0: "tpdu-size", 0xc1: "src-tsap", 0xc2: "dst-tsap"}

CotpPduType = {0xe0: "CR", 0xd0: "CC", 0xf0: "DT"}

S7_Function_Status = ['MoreData', 'Error']

S7_Block_Type_In_Block = {
    0x08: 'OB',
    0x0a: 'DB',
    0x0b: 'SDB',
    0x0c: 'FC',
    0x0d: 'SFC',
    0x0e: 'FB',
    0x0f: 'SFB'
}


class TpktReq(Packet):
    name = "TPKT_Req"
    fields_desc = [
        XByteField("Version", 0x03),
        XByteField("Reserved", 0x00),
        XShortField("Length", None)
    ]

    def post_build(self, p, pay):
        if self.Length is None and pay:
            l = len(p) + len(pay)
            p = p[:2] + struct.pack("!H", l) + p[4:]
        return p + pay

    def guess_payload_class(self, payload):
        if payload[1] == '\xe0':
            return CotpCr
        elif payload[1] == '\xd0':
            return CotpCc
        elif payload[1] == '\xf0':
            return CotpDtReq
        else:
            return None


class TpktRsp(Packet):
    name = "TPKT_Rsp"
    fields_desc = [
        XByteField("Version", 0x03),
        XByteField("Reserved", 0x00),
        XShortField("Length", None)
    ]

    def post_build(self, p, pay):
        if self.Length is None and pay:
            l = len(p) + len(pay)
            p = p[:2] + struct.pack("!H", l) + p[4:]
        return p + pay

    def guess_payload_class(self, payload):
        if payload[1] == '\xe0':
            return CotpCr
        elif payload[1] == '\xd0':
            return CotpCc
        elif payload[1] == '\xf0':
            return CotpDtRsp
        else:
            return None


class CotpOption(Packet):
    name = "COTP_OPTION"
    fields_desc = [
        ByteEnumField("ParameterCode", 0xc0, CotpParameterCode),
        FieldLenField("ParameterLength", None, fmt="B", length_of="Parameter", adjust=lambda pkt, x: x),
        StrLenField("Parameter", None, length_from=lambda p: p.ParameterLength)
    ]

    def extract_padding(self, p):
        return "", p


class CotpCr(Packet):
    name = "COTP_CR"
    fields_desc = [
        FieldLenField("COTPLength", None, fmt="B", length_of="Parameters", adjust=lambda pkt, x: (x + 6)),
        ByteEnumField("PDUType", 0xe0, CotpPduType),
        XShortField("Dref", 0x0000),
        XShortField("Sref", 0x0005),
        XByteField("ClassOption", 0x00),
        PacketListField("Parameters", [], CotpOption, length_from=lambda p: p.COTPLength - 6)
    ]


class CotpCc(Packet):
    name = "COTP_CC"
    fields_desc = [
        FieldLenField("COTPLength", None, fmt="B", length_of="Parameters", adjust=lambda pkt, x: (x + 6)),
        ByteEnumField("PDUType", 0xd0, CotpPduType),
        XShortField("Dref", 0x0000),
        XShortField("Sref", 0x0012),
        XByteField("ClassOption", 0x00),
        PacketListField("Parameters", [], CotpOption, length_from=lambda p: p.COTPLength - 6)
    ]


class CotpDtReq(Packet):
    name = "COTP_DT_REQ"
    fields_desc = [
        XByteField("COTPLength", 0x02),
        ByteEnumField("PDUType", 0xf0, CotpPduType),
        FlagsField("EOT", 0, 1, ["End", "Not end"]),
        BitField("TPDUNR", 0, 7)
    ]

    def guess_payload_class(self, payload):
        # print payload.encode('hex')
        if payload[0] == '\x32':
            # ROSCTR: Job (1)
            if payload[1] == '\x01':
                # Function: Setup communication (0xf0)
                if payload[10] == '\xf0':
                    return S7SetConReq
                # Function: Read Var (0x04)
                if payload[10] == '\x04':
                    return S7ReadVarReq
                # Function: Write Var (0x05)
                if payload[10] == '\x05':
                    return S7WriteVarReq
                # Function: Start upload (0x1d)
                if payload[10] == '\x1d':
                    return S7RequestUploadBlockReq
                # Function: Upload (0x1e)
                if payload[10] == '\x1e':
                    return S7UploadBlockReq
                # Function: End upload (0x1f)
                if payload[10] == '\x1f':
                    return S7UploadBlockEndReq
                # Function: PI-Service (0x28)
                if payload[10] == '\x28':
                    return S7PIServiceReq

            # ROSCTR: Ack_Data (3)
            if payload[1] == '\x03':
                # Function: Read Var (0x04)
                if payload[12] == '\x04':
                    return S7ReadVarRsp
                # Function: Write Var (0x05)
                if payload[12] == '\x05':
                    return S7WriteVarReq
                # Function: Upload (0x1e)
                if payload[12] == '\x1e':
                    return S7UploadBlockRsp
                # Function: End upload (0x1f)
                if payload[12] == '\x1f':
                    return S7UploadBlockEndRsp

            # ROSCTR: UserData (7)
            if payload[1] == '\x07':
                if payload[10:13] == '\x00\x01\x12':
                    # SubFunction: Read SZL (1)
                    if payload[15:17] == '4401':
                        return S7ReadSZLReq
                    if payload[15:17] == '4301':
                        return S7ListBlockReq
                    if payload[15:17] == '4302':
                        return S7ListBlockOfTypeReq
                    if payload[15:17] == '4303':
                        return S7GetBlockInfoReq
        else:
            return None


class CotpDtRsp(Packet):
    name = "COTP_DT_RSP"
    fields_desc = [
        XByteField("COTPLength", 0x02),
        ByteEnumField("PDUType", 0xf0, CotpPduType),
        FlagsField("EOT", 0, 1, ["End", "Not end"]),
        BitField("TPDUNR", 0, 7)
    ]

    def guess_payload_class(self, payload):
        # print payload.encode('hex')
        if payload[0] == '\x32':
            if payload[1] == '\x01':  # ROSCTR: Job (1)
                # Function: Read Var (0x04)
                if payload[10] == '\x04':
                    return S7ReadVarReq
                # Function: Write Var (0x05)
                if payload[10] == '\x05':
                    return S7WriteVarReq
                # Function: Start upload (0x1d)
                if payload[10] == '\x1d':
                    return S7RequestUploadBlockReq
                # Function: Upload (0x1e)
                if payload[10] == '\x1e':
                    return S7UploadBlockReq
                # Function: End upload (0x1f)
                if payload[10] == '\x1f':
                    return S7UploadBlockEndReq

            if payload[1] == '\x02':  # ROSCTR: Ack (2)
                return S7AckRsp

            if payload[1] == '\x03':  # ROSCTR: Ack_Data (3)
                # Function: Read Var (0x04)
                if payload[12] == '\x04':
                    return S7ReadVarRsp
                # Function: Write Var (0x05)
                if payload[12] == '\x05':
                    return S7WriteVarReq
                # Function: Request download (0x1a)
                if payload[12] == '\x1a':
                    return S7RequestDownloadBlockRsp
                # Function: Start upload (0x1d)
                if payload[12] == '\x1d':
                    return S7RequestUploadBlockRsp
                # Function: Upload (0x1e)
                if payload[12] == '\x1e':
                    return S7UploadBlockRsp
                # Function: End upload (0x1f)
                if payload[12] == '\x1f':
                    return S7UploadBlockEndRsp
                # Function: PI - Service(0x28)
                if payload[12] == '\x28':
                    return S7PIServiceRsp
                # Function: PLC Stop (0x29)
                if payload[12] == '\x29':
                    return S7StopCpuRsp
                # Function: Setup communication (0xf0)
                if payload[12] == '\xf0':
                    return S7SetConRsp

            if payload[1] == '\x07':  # ROSCTR: Userdata (7)
                if payload.encode('hex')[20:26] == '000112':
                    # Subfunction: Read SZL (1)
                    if payload.encode('hex')[30:34] == '4401':
                        return S7ReadSZLReq
                    if payload.encode('hex')[30:34] == '8401':
                        return S7ReadSZLRsp
                    # Subfunction: List Block (1)
                    if payload.encode('hex')[30:34] == '4301':
                        return S7ListBlockReq
                    if payload.encode('hex')[30:34] == '8301':
                        return S7ListBlockRsp
                    if payload.encode('hex')[30:34] == '4302':
                        return S7ListBlockOfTypeReq
                    if payload.encode('hex')[30:34] == '8302':
                        return S7ListBlockOfTypeRsp
                    if payload.encode('hex')[30:34] == '4303':
                        return S7GetBlockInfoReq
                    if payload.encode('hex')[30:34] == '8303':
                        return S7GetBlockInfoRsp
        else:
            return None


###########SetCon#####################
class S7SetConParameter(Packet):
    name = "S7_SetCon_Parameter"
    fields_desc = [
        ByteEnumField("Function", 0xf0, S7_JB_Function),
        XByteField("Reserved", 0x00),
        XShortField("MaxAmQcalling", 0x0001),
        XShortField("MaxAmQcalled", 0x0001),
        XShortField("PDULength", 0x01e0)
    ]


class S7SetConReq(Packet):
    name = "S7_SetCon_Req"
    fields_desc = [
        XByteField("ProtocolId", 0x32),
        ByteEnumField("ROSCTR", 0x01, S7_PDU_Type),
        XShortField("RedundancyId", 0x0000),
        LEShortField("PDUR", 0x0000),
        FieldLenField("ParameterLength", None, fmt="H", length_of="Parameters", adjust=lambda pkt, x: x),
        XShortField("DataLength", 0x0000),
        PacketLenField(
            "Parameters",
            S7SetConParameter(),
            S7SetConParameter,
            length_from=lambda x: x.ParameterLength
        )
    ]


class S7SetConRsp(Packet):
    name = "S7_SetCon_Rsp"
    fields_desc = [
        XByteField("ProtocolId", 0x32),
        ByteEnumField("ROSCTR", 0x03, S7_PDU_Type),
        XShortField("RedundancyId", 0x0000),
        LEShortField("PDUR", 0x0000),
        FieldLenField("ParameterLength", None, fmt="H", length_of="Parameters", adjust=lambda pkt, x: x),
        XShortField("DataLength", 0x0000),
        PacketLenField(
            "Parameters",
            S7SetConParameter(),
            S7SetConParameter,
            length_from=lambda x: x.ParameterLength
        )
    ]

class S7AckRsp(Packet):
    name = "S7_AcK_Rsp"
    fields_desc = [
        XByteField("ProtocolId", 0x32),
        ByteEnumField("ROSCTR", 0x02, S7_PDU_Type),
        XShortField("RedundancyId", 0x0000),
        LEShortField("PDUR", 0x0000),
        XShortField("ParameterLength", 0x0000),
        XShortField("DataLength", 0x0000),
        ByteEnumField("ErrorClass", 0x00, S7_Error_Class),
        XByteField("ErrorCode", 0x00)
    ]


###########Read-SZL-request################
class S7ReadSZLParameterReq(Packet):
    name = "S7_ReadSZL_Parameter_TPDU"
    fields_desc = [
        X3BytesField("ParameterHead", 0x000112),
        XByteField("ParameterLength", None),
        XByteField("Code", 0x11),
        BitField("Type", 4, 4),
        BitField("FunctionGroup", 4, 4),
        ByteEnumField("SubFunction", 0x01, {0x01: "Read SZL"}),
        XByteField("seq", 0x00)
    ]

    def post_build(self, p, pay):
        if self.ParameterLength is None:
            l = len(p) - 4
            p = p[:3] + struct.pack("!B", l) + p[4:]
        return p + pay


class S7ReadSZLDataReq(Packet):
    name = "S7_ReadSZL_Data_Req"
    fields_desc = [
        ByteEnumField("ReturnCode", 0xff, S7_Return_Code),
        XByteField("TransportSize", 0x09),
        FieldLenField("Length", None, fmt="H", length_of="SZLIndex", adjust=lambda pkt, x: x + 2),
        XShortField("SZLId", 0x001c),
        XShortField("SZLIndex", 0x0000)
    ]


class S7ReadSZLReq(Packet):
    name = "S7_ReadSZL_Req"
    fields_desc = [
        XByteField("ProtocolId", 0x32),
        ByteEnumField("ROSCTR", 0x07, S7_PDU_Type),
        XShortField("RedundancyId", 0x0000),
        LEShortField("PDUR", 0x0100),
        FieldLenField("ParameterLength", None, fmt="H", length_of="Parameters", adjust=lambda pkt, x: x),
        FieldLenField("DataLength", None, fmt="H", length_of="Data", adjust=lambda pkt, x: x),
        PacketLenField(
            "Parameters",
            S7ReadSZLParameterReq(),
            S7ReadSZLParameterReq,
            length_from=lambda x: x.ParameterLength
        ),
        PacketLenField(
            "Data",
            S7ReadSZLDataReq(),
            S7ReadSZLDataReq,
            length_from=lambda x: x.DataLength
        )
    ]


###########Read-SZL-Response################
class S7ReadSZLParameterRsp(Packet):
    name = "S7_ReadSZL_Parameter_Response_TPDU"
    fields_desc = [
        X3BytesField("ParameterHead", 0x000112),
        XByteField("ParameterLength", None),
        XByteField("Code", 0x11),
        BitField("Type", 8, 4),
        BitField("FunctionGroup", 4, 4),
        ByteEnumField("SubFunction", 0x01, {0x01: "Read SZL"}),
        XByteField("seq", 0x00),
        XByteField("DURN", 0x00),
        XByteField("LastUnit", 0x00),
        XShortEnumField("ErrorCode", 0x0000, S7_Error_Class)
    ]

    def post_build(self, p, pay):
        if self.ParameterLength is None:
            l = len(p) - 4
            p = p[:3] + struct.pack("!B", l) + p[4:]
        return p + pay


class S7ReadSZLDataTreeRsp(Packet):
    name = "S7_ReadSZL_Data_Tree"
    fields_desc = [StrField("Data", "\x00", fmt="H")]

    def extract_padding(self, p):
        return "", p


class S7ReadSZLDataRsp(Packet):
    name = "S7_ReadSZL_Data_Response"
    fields_desc = [
        ByteEnumField("ReturnCode", 0xff, S7_Return_Code),
        XByteField("TransportSize", 0x09),
        XShortField("Length", None),
        XShortField("SZLId", 0x001c),
        XShortField("SZLIndex", 0x0000),
        FieldLenField("SZLLength", None, length_of="SZLDataTree", fmt="H", adjust=lambda pkt, x: x / x.SZLDataTree),
        FieldLenField("SZLListCount", None, count_of="SZLDataTree", fmt="H", adjust=lambda pkt, x: x),
        PacketListField("SZLDataTree", [], S7ReadSZLDataTreeRsp, length_from=lambda x: x.SZLLength * x.SZLListCount)
    ]

    def post_build(self, p, pay):
        if self.Length is None:
            l = len(p) - 4
            p = p[:2] + struct.pack("!H", l) + p[4:]
        return p + pay


class S7ReadSZLRsp(Packet):
    name = "S7_ReadSZL_Response"
    fields_desc = [
        XByteField("ProtocolId", 0x32),
        ByteEnumField("ROSCTR", 0x07, S7_PDU_Type),
        XShortField("RedundancyId", 0x0000),
        LEShortField("PDUR", 0x0100),
        FieldLenField("ParameterLength", None, fmt="H", length_of="Parameters", adjust=lambda pkt, x: x),
        FieldLenField("DataLength", None, fmt="H", length_of="Data", adjust=lambda pkt, x: x),
        PacketLenField("Parameters", None, S7ReadSZLParameterRsp, length_from=lambda x: x.ParameterLength),
        PacketField("Data", None, S7ReadSZLDataRsp)
    ]


###########List-Block-Req##############
class S7ListBlockDataReq(Packet):
    name = "S7_ListBlock_Data_Req"
    fields_desc = [
        # todo: Might be 0x0a
        ByteEnumField("ReturnCode", 0xff, S7_Return_Code),
        XByteField("Size", 0x00),
        XShortField("Length", 0x0000)
    ]


class S7ListBlockParameterReq(Packet):
    name = "S7_ListBlock_Parameter_Req"
    fields_desc = [
        X3BytesField("Head", 0x000112),
        XByteField("Length", 0x04),
        XByteField("Unknown1", 0x11),
        XByteField("Unknown2", 0x43),
        XByteField("SubFunction", 0x01),
        XByteField("Sequence", 0x0)
    ]


class S7ListBlockReq(Packet):
    name = "S7_ListBlock_Req"
    fields_desc = [
        XByteField("ProtocolId", 0x32),
        ByteEnumField("ROSCTR", 0x07, S7_PDU_Type),
        XShortField("RedundancyId", 0x0000),
        LEShortField("PDUR", 0x0000),
        FieldLenField("ParameterLength", None, fmt="H", length_of="Parameters", adjust=lambda pkt, x: x),
        FieldLenField("DataLength", None, fmt="H", length_of="Data", adjust=lambda pkt, x: x),
        PacketLenField("Parameters",
                       S7ListBlockParameterReq(),
                       S7ListBlockParameterReq,
                       length_from=lambda x: x.ParameterLength
                       ),
        PacketLenField("Data",
                       S7ListBlockDataReq(),
                       S7ListBlockDataReq,
                       length_from=lambda x: x.DataLength
                       )
    ]


###########List-Block-Rsp##############
class S7ListBlockDataBlocksRsp(Packet):
    name = "S7_ListBlock_Data_Blocks_Rsp"
    fields_desc = [
        XByteField("Unknow", 0x30),
        ByteEnumField("BlockType", 0x38, S7_Block_Type),
        XShortField("BlockCount", 1)
    ]

    def extract_padding(self, p):
        return "", p


class S7ListBlockDataRsp(Packet):
    name = "S7_ListBlock_Data_Rsp"
    fields_desc = [
        ByteEnumField("ReturnCode", 0xff, S7_Return_Code),
        XByteField("Size", 0x09),
        FieldLenField("DataLength", None, fmt="H", length_of="Blocks"),
        PacketListField("Blocks", [], S7ListBlockDataBlocksRsp, length_from=lambda p: p.DataLength)
    ]


class S7ListBlockParameterRsp(Packet):
    name = "S7_ListBlock_Parameter_Rsp"
    fields_desc = [
        X3BytesField("Head", 0x000112),
        XByteField("Length", 0x08),
        XByteField("Unknown1", 0x12),
        XByteField("Unknown2", 0x83),
        XByteField("SubFunction", 0x01),
        XByteField("Sequence", 0x1),
        XByteField("DURN", 0x00),
        XByteField("LastUnit", 0x00),
        XShortEnumField("ErrorCode", 0x0000, S7_Error_Class)
    ]


class S7ListBlockRsp(Packet):
    name = "S7_ListBlock_Rsp"
    fields_desc = [
        XByteField("ProtocolId", 0x32),
        ByteEnumField("ROSCTR", 0x07, S7_PDU_Type),
        XShortField("RedundancyId", 0x0000),
        LEShortField("PDUR", 0x0000),
        FieldLenField("ParameterLength", None, fmt="H", length_of="Parameters", adjust=lambda pkt, x: x),
        FieldLenField("DataLength", None, fmt="H", length_of="Data", adjust=lambda pkt, x: x),
        PacketLenField("Parameters", None, S7ListBlockParameterRsp, length_from=lambda x: x.ParameterLength),
        PacketLenField("Data", None, S7ListBlockDataRsp, length_from=lambda x: x.DataLength)
    ]


###########List-Block-of-type-Req##############
class S7ListBlockOfTypeDataReq(Packet):
    name = "S7_ListBlock_Of_Type_Data_Req"
    fields_desc = [
        ByteEnumField("ReturnCode", 0xff, S7_Return_Code),
        XByteField("Size", 0x09),
        XShortField("Length", 0x0002),
        XByteField("UnKnown", 0x30),
        ByteEnumField("BlockType", 0x38, S7_Block_Type),
    ]


class S7ListBlockOfTypeParameterReq(Packet):
    name = "S7_ListBlock_of_Type_Parameter_Req"
    fields_desc = [
        X3BytesField("Head", 0x000112),
        XByteField("Length", 0x04),
        XByteField("UnKnown1", 0x11),
        XByteField("UnKnown2", 0x43),
        XByteField("SubFunction", 0x02),
        XByteField("Sequence", 0x0)
    ]


class S7ListBlockOfTypeReq(Packet):
    name = "S7_ListBlock_of_Type_Req"
    fields_desc = [
        XByteField("ProtocolId", 0x32),
        ByteEnumField("ROSCTR", 0x07, S7_PDU_Type),
        XShortField("RedundancyId", 0x0000),
        LEShortField("PDUR", 0x0000),
        FieldLenField("ParameterLength", None, fmt="H", length_of="Parameters", adjust=lambda pkt, x: x),
        FieldLenField("DataLength", None, fmt="H", length_of="Data", adjust=lambda pkt, x: x),
        PacketField("Parameters", S7ListBlockOfTypeParameterReq(), S7ListBlockOfTypeParameterReq),
        PacketField("Data", S7ListBlockOfTypeDataReq(), S7ListBlockOfTypeDataReq)
    ]


###########List-Block-Rsp##############
class S7ListBlockOfTypeDataBlocksRsp(Packet):
    name = "S7_ListBlock_of_Type_Data_Blocks_Rsp"
    fields_desc = [
        XShortField("BlockNum", 0x0002),
        XByteField("BlockFlag", 0x12),
        ByteEnumField("BlockLang", 0x07, S7_BlockLang_Type)
    ]

    def extract_padding(self, p):
        return "", p


class S7ListBlockOfTypeDataRsp(Packet):
    name = "S7_ListBlock_Data_Rsp"
    fields_desc = [
        ByteEnumField("ReturnCode", 0xff, S7_Return_Code),
        XByteField("Size", 0x09),
        FieldLenField("DataLength", None, fmt="H", length_of="Blocks"),
        PacketListField("Blocks", [], S7ListBlockOfTypeDataBlocksRsp, length_from=lambda p:p.DataLength)
    ]


class S7ListBlockOfTypeParameterRsp(Packet):
    name = "S7_ListBlock_of_Type_Parameter_Rsp"
    fields_desc = [
        X3BytesField("Head", 0x000112),
        XByteField("Length", 0x08),
        XByteField("UnKnown1", 0x12),
        XByteField("UnKnown2", 0x83),
        XByteField("SubFunction", 0x02),
        XByteField("Sequence", 0x1),
        XByteField("DURN", 0x00),
        XByteField("LastUnit", 0x00),
        XShortEnumField("ErrorCode", 0x0000, S7_Error_Class)
    ]


class S7ListBlockOfTypeRsp(Packet):
    name = "S7_ListBlock_of_Type_TPDU_Rsp"
    fields_desc = [
        XByteField("ProtocolId", 0x32),
        ByteEnumField("ROSCTR", 0x07, S7_PDU_Type),
        XShortField("RedundancyId", 0x0000),
        LEShortField("PDUR", 0x0000),
        FieldLenField("ParameterLength", None, fmt="H", length_of="Parameters", adjust=lambda pkt, x: x),
        FieldLenField("DataLength", None, fmt="H", length_of="Data", adjust=lambda pkt, x: x),
        PacketLenField("Parameters", None, S7ListBlockOfTypeParameterRsp, length_from=lambda x: x.ParameterLength),
        PacketLenField("Data", None, S7ListBlockOfTypeDataRsp, length_from=lambda x: x.DataLength)
    ]


#########Get-Block-Info-req########
class S7GetBlockInfoDataReq(Packet):
    name = "S7_GetBlock_Info_Data_Req"
    fields_desc = [
        ByteEnumField("ReturnCode", 0xff, S7_Return_Code),
        XByteField("Size", 0x09),
        XShortField("Length", 0x0008),
        XByteField("UnKnown", 0x30),
        ByteEnumField("BlockType", 0x38, S7_Block_Type),
        StrFixedLenField("BlockNum", "01000", length=5),
        XByteField("DstFileSystem", 0x41)
    ]


class S7GetBlockInfoParameterReq(Packet):
    name = "S7_GetBlock_Info_Parameter_Req"
    fields_desc = [
        X3BytesField("Head", 0x000112),
        XByteField("Length", 0x04),
        XByteField("UnKnown1", 0x11),
        XByteField("UnKnown2", 0x43),
        XByteField("SubFunction", 0x03),
        XByteField("Sequence", 0x0)
    ]


class S7GetBlockInfoReq(Packet):
    name = "S7_GetBlock_Info_Req"
    fields_desc = [
        XByteField("ProtocolId", 0x32),
        ByteEnumField("ROSCTR", 0x07, S7_PDU_Type),
        XShortField("RedundancyId", 0x0000),
        LEShortField("PDUR", 0x0000),
        FieldLenField("ParameterLength", None, fmt="H", length_of="Parameters", adjust=lambda pkt, x: x),
        FieldLenField("DataLength", None, fmt="H", length_of="Data", adjust=lambda pkt, x: x),
        PacketField("Parameters", S7GetBlockInfoParameterReq(), S7GetBlockInfoParameterReq),
        PacketField("Data", S7GetBlockInfoDataReq(), S7GetBlockInfoDataReq)
    ]


#########Get-Block-Info-Rsp########
class S7GetBlockInfoDataInfoRsp(Packet):
    name = "S7_GetBlock_Info_Data_block_Rsp"
    fields_desc = (
        XByteField("Constant", 0x01),
        XByteField("BlockType", 0x00),
        FieldLenField("Length", None, fmt="H", length_of='Info', adjust=lambda pkt, x: x - 4),
        StrLenField("Info", "", length_from=lambda pkt: pkt.Length)
        # Todo: Finish Info field
    )


class S7GetBlockInfoDataRsp(Packet):
    name = "S7_GetBlock_Info_Data_Rsp"
    fields_desc = [
        ByteEnumField("ReturnCode", 0xff, S7_Return_Code),
        XByteField("Size", 0x09),
        FieldLenField("Length", None, fmt="H", length_of="Info"),
        PacketField("Info", S7GetBlockInfoDataInfoRsp(), S7GetBlockInfoDataInfoRsp)
    ]


class S7GetBlockInfoParameterRsp(Packet):
    name = "S7_GetBlock_Info_Parameter_Rsp"
    fields_desc = [
        X3BytesField("Head", 0x000112),
        XByteField("Length", 0x08),
        XByteField("Unknown1", 0x12),
        XByteField("Unknown2", 0x83),
        XByteField("SubFunction", 0x03),
        XByteField("Sequence", 0x1),
        XByteField("DURN", 0x00),
        XByteField("LastUnit", 0x00),
        XShortEnumField("ErrorCode", 0x0000, S7_Error_Class)
    ]


class S7GetBlockInfoRsp(Packet):
    name = "S7_GetBlock_Info_TPDU_Rsp"
    fields_desc = [
        XByteField("ProtocolId", 0x32),
        ByteEnumField("ROSCTR", 0x07, S7_PDU_Type),
        XShortField("RedundancyId", 0x0000),
        LEShortField("PDUR", 0x0000),
        FieldLenField("ParameterLength", None, fmt="H", length_of="Parameters", adjust=lambda pkt, x: x),
        FieldLenField("DataLength", None, fmt="H", length_of="Data", adjust=lambda pkt, x: x),
        PacketField("Parameters", S7GetBlockInfoParameterRsp(), S7GetBlockInfoParameterRsp),
        PacketField("Data", S7GetBlockInfoDataRsp(), S7GetBlockInfoDataRsp)
    ]


###########Read-Var################
class S7ReadVarItemsReq(Packet):
    name = "S7_ReadVar_Items_Req"
    fields_desc = [
        XByteField("VariableSpecification", 0x12),
        XByteField("ParameterLength", None),
        XByteField("SyntaxId", 0x10),
        ByteEnumField("TransportSize", 0x02, S7_Transport_Size),
        XShortField("GetLength", 0x0016),
        XShortField("BlockNum", 0x0000),
        ByteEnumField("AREAType", 0x84, S7_AREA_Type),
        X3BytesField("Address", 0x000000)
    ]

    def extract_padding(self, p):
        return "", p

    def post_build(self, p, pay):
        if self.ParameterLength is None:
            l = len(p) - 2
            p = p[:1] + struct.pack("!B", l) + p[2:]
        return p + pay


class S7ReadVarParameterReq(Packet):
    name = "S7_ReadVar_Parameter_Req"
    fields_desc = [
        ByteEnumField("Function", 0x04, S7_JB_Function),
        FieldLenField("ItemCount", None, fmt="B", count_of="Items"),
        PacketListField("Items", None, S7ReadVarItemsReq)
    ]


class S7ReadVarReq(Packet):
    name = "S7_ReadVar_Req"
    fields_desc = [
        XByteField("ProtocolId", 0x32),
        ByteEnumField("ROSCTR", 0x01, S7_PDU_Type),
        XShortField("RedundancyId", 0x0000),
        LEShortField("PDUR", 0x2000),
        FieldLenField("ParameterLength", None, fmt="H", length_of="Parameters", adjust=lambda pkt, x: x),
        # Todo: Might be useful in some case
        # FieldLenField("DataLength", None, fmt="H", length_of="Data", adjust=lambda pkt, x: x),
        XShortField("DataLength", 0x0000),
        PacketField("Parameters", S7ReadVarParameterReq(), S7ReadVarParameterReq)
    ]


###########Read-Var-Response################
class S7ReadVarItemsRsp(Packet):
    name = "S7_ReadVar_Items_Response"
    fields_desc = [
        ByteEnumField("ReturnCode", 0xff, S7_Return_Code),
        ByteEnumField("TransportSize", 0x04, S7_Transport_Size),
        # todo: 需要解决不同的长度计算方式产生的问题,目前只支持(BYTE/WORD/DWORD 0x04)
        FieldLenField("DataLength", None, fmt="H", length_of="Data", adjust=lambda pkt, x: x * 8),
        StrLenField("Data", "\x00", length_from=lambda p: p[S7ReadVarItemsRsp].DataLength / 8)
    ]

    def extract_padding(self, p):
        return "", p


class S7ReadVarParameterRsp(Packet):
    name = "S7_ReadVar_Parameter_Response"
    fields_desc = [
        ByteEnumField("Function", 0x04, S7_JB_Function),
        FieldLenField("ItemCount", None, fmt="B", count_of="Items"),
        PacketListField("Items", None, S7ReadVarItemsRsp)
    ]


class S7ReadVarRsp(Packet):
    name = "S7_ReadVar_Response"
    fields_desc = [
        XByteField("ProtocolId", 0x32),
        ByteEnumField("ROSCTR", 0x03, S7_PDU_Type),
        XShortField("RedundancyId", 0x0000),
        LEShortField("PDUR", 0x2000),
        FieldLenField("ParameterLength", None, fmt="H", length_of="Parameters", adjust=lambda pkt, x: x),
        # Todo: Might be useful in some case
        # FieldLenField("DataLength", None, fmt="H", length_of="Data", adjust=lambda pkt, x: x),
        XShortField("DataLength", 0x0000),
        ByteEnumField("ErrorClass", 0x00, S7_Error_Class),
        XByteField("ErrorCode", 0x00),
        PacketField("Parameters", None, S7ReadVarParameterRsp)
    ]


###########Write-Var################
class S7WriteVarItemsReq(Packet):
    name = "S7_WriteVar_Items_Req"
    fields_desc = [
        XByteField("VariableSpecification", 0x12),
        XByteField("ParameterLength", None),
        XByteField("SyntaxId", 0x10),
        ByteEnumField("TransportSize", 0x02, S7_Transport_Size),
        # todo: 长度会根据实际情况产生变化（需要根据data长度自行判断）
        XShortField("WriteLength", 0x0016),
        XShortField("BlockNum", 0x0000),
        ByteEnumField("AREAType", 0x84, S7_AREA_Type),
        X3BytesField("Address", 0x000000)
    ]

    def extract_padding(self, p):
        return "", p

    def post_build(self, p, pay):
        if self.ParameterLength is None:
            l = len(p) - 2
            p = p[:1] + struct.pack("!B", l) + p[2:]
        return p + pay


class S7WriteVarParameterReq(Packet):
    name = "S7_WriteVar_Parameter_Req"
    fields_desc = [
        ByteEnumField("Function", 0x05, S7_JB_Function),
        FieldLenField("ItemCount", None, fmt="B", count_of="Items"),
        PacketListField("Items", None, S7WriteVarItemsReq, count_from=lambda p:p.ItemCount)
    ]


class S7WriteVarDataReq(Packet):
    name = "S7_WriteVar_Data_Field"
    fields_desc = [
        ByteEnumField("ReturnCode", 0x00, S7_Return_Code),
        ByteEnumField("TransportSize", 0x04, S7_Transport_Size),
        FieldLenField("DataLength", None, fmt="H", length_of="Data", adjust=lambda p, x: x * 8),
        PadField(
            StrLenField("Data", "\x00", length_from=lambda p: p[S7WriteVarDataReq].Length / 8),
            1,
            padwith="\x18"
        ),
        # Todo: If this padfield work's well we can safely remove this
        # StrLenField("Data", "\x00", length_from=lambda p: p[S7WriteVarDataReq].Length / 8)
        # ConditionalField(XByteField("FillByte", 0x18), lambda pkt: True if len(
        #                pkt[S7WriteVarDataReq].Data) % 2 == 1 else False)
    ]

    def extract_padding(self, p):
        return "", p


class S7WriteVarReq(Packet):
    name = "S7_WriteVar_Req"
    fields_desc = [
        XByteField("ProtocolId", 0x32),
        ByteEnumField("ROSCTR", 0x01, S7_PDU_Type),
        XShortField("RedundancyId", 0x0000),
        LEShortField("PDUR", 0xbc00),
        FieldLenField("ParameterLength", None, fmt="H", length_of="Parameters", adjust=lambda pkt, x: x),
        FieldLenField("DataLength", None, fmt="H", length_of="Data", adjust=lambda pkt, x: x),
        PacketLenField(
            "Parameters",
            S7WriteVarParameterReq(),
            S7WriteVarParameterReq,
            length_from=lambda x: x.ParameterLength
        ),
        PacketLenField("Data", S7WriteVarDataReq(), S7WriteVarDataReq, length_from=lambda x: x.DataLength)
    ]


###########Download-Block################
class S7RequestDownloadBlockParameterReq(Packet):
    name = "S7_RequestDownloadBlock_Parameter_Req"
    fields_desc = [
        ByteEnumField("Function", 0x1a, S7_JB_Function),
        XByteField("FunctionStatus", 0x00),
        StrFixedLenField("UnKnown1", "\x01\x00\x00\x00\x00\x00", length=6),
        XByteField("FileNameLength", 0x09),
        XByteField("FileId", 0x5f),
        XByteField("UnKnown2", 0x30),
        ByteEnumField("BlockType", 0x43, S7_Block_Type),
        StrFixedLenField("BlockNum", "00000", length=5),
        XByteField("DstFileSystem", 0x50),
        XByteField("Length2", 0x0d),
        XByteField("UnKnown3", 0x31),
        StrFixedLenField("LoadMemLength", "000256", length=6),
        StrFixedLenField("MC7Length", "000156", length=6)
    ]


class S7RequestDownloadBlockReq(Packet):
    name = "S7_Request_Download_Block_Req"
    fields_desc = [
        XByteField("ProtocolId", 0x32),
        ByteEnumField("ROSCTR", 0x01, S7_PDU_Type),
        XShortField("RedundancyId", 0x0000),
        LEShortField("PDUR", 0x0d00),
        FieldLenField("ParameterLength", None, length_of="Parameters", adjust=lambda pkt, x: x),
        XShortField("DataLength", None),
        PacketLenField(
            "Parameters",
            S7RequestDownloadBlockParameterReq(),
            S7RequestDownloadBlockParameterReq,
            length_from=lambda x: x.ParameterLength
        )
    ]


class S7RequestDownloadBlockParameterRsp(Packet):
    name = "S7_RequestDownloadBlock_Parameter_Rsp"
    fields_desc = [
        ByteEnumField("Function", 0x1a, S7_JB_Function)
    ]


class S7RequestDownloadBlockRsp(Packet):
    name = "S7_Request_Download_Block_Rsp"
    fields_desc = [
        XByteField("ProtocolId", 0x32),
        ByteEnumField("ROSCTR", 0x03, S7_PDU_Type),
        XShortField("RedundancyId", 0x0000),
        LEShortField("PDUR", 0x0d00),
        FieldLenField("ParameterLength", None, length_of="Parameters", adjust=lambda pkt, x: x),
        XShortField("DataLength", None),
        ByteEnumField("ErrorClass", 0x00, S7_Error_Class),
        XByteField("ErrorCode", 0x00),
        PacketLenField(
            "Parameters",
            S7RequestDownloadBlockParameterRsp(),
            S7RequestDownloadBlockParameterRsp,
            length_from=lambda x: x.ParameterLength
        )
    ]


class S7DownloadBlockDataRsp(Packet):
    name = "S7_DownloadBlock_Data_Rsp"
    fields_desc = [
        FieldLenField("DataLength", None, length_of="Data", adjust=lambda pkt, x:x),
        XShortField("UnKnown1", 0x00fb),
        StrLenField("Data", "\x00", length_from=lambda x: x.DataLength)
    ]


class S7DownloadBlockParameterRsp(Packet):
    name = "S7_DownloadBlock_Parameter_Rsp"
    fields_desc = [
        ByteEnumField("Function", 0x1b, S7_JB_Function),
        BitField("Unused", 0, 6),
        FlagsField("FunctionStatus", 0, 2, S7_Function_Status)
    ]


class S7DownloadBlockRsp(Packet):
    name = "S7_Download_Block_Rsp"
    fields_desc = [
        XByteField("ProtocolId", 0x32),
        ByteEnumField("ROSCTR", 0x03, S7_PDU_Type),
        XShortField("RedundancyId", 0x0000),
        XShortField("PDUR", 0x00d0),
        FieldLenField("ParameterLength", None, fmt="H", length_of="Parameters", adjust=lambda pkt, x: x),
        FieldLenField("DataLength", None, fmt="H", length_of="Data", adjust=lambda pkt, x: x),
        ByteEnumField("ErrorClass", 0x00, S7_Error_Class),
        XByteField("ErrorCode", 0x00),
        PacketLenField(
            "Parameters",
            S7DownloadBlockParameterRsp(),
            S7DownloadBlockParameterRsp,
            length_from=lambda x: x.ParameterLength
        ),
        PacketLenField(
            "Data",
            S7DownloadBlockDataRsp(),
            S7DownloadBlockDataRsp,
            length_from=lambda x: x.DataLength
        )
    ]


class S7DownloadBlockEndParameterRsp(Packet):
    name = "S7_DownloadBlockEnd_Parameter_Rsp"
    fields_desc = [
        ByteEnumField("Function", 0x1c, S7_JB_Function),
    ]


class S7DownloadBlockEndRsp(Packet):
    name = "S7_DownloadBlockEnd_Rsp"
    fields_desc = [
        XByteField("ProtocolId", 0x32),
        ByteEnumField("ROSCTR", 0x03, S7_PDU_Type),
        XShortField("RedundancyId", 0x0000),
        XShortField("PDUR", 0x00d0),
        FieldLenField("ParameterLength", None, fmt="H", length_of="Parameters", adjust=lambda pkt, x: x),
        XShortField("DataLength", 0),
        ByteEnumField("ErrorClass", 0x00, S7_Error_Class),
        XByteField("ErrorCode", 0x00),
        PacketLenField(
            "Parameters",
            S7DownloadBlockEndParameterRsp(),
            S7DownloadBlockEndParameterRsp,
            length_from=lambda x: x.ParameterLength
        )
    ]


##############Download File#############
class S7RequestDownloadFileParameterReq(Packet):
    name = "S7_RequestDownloadBlock_Parameter_Req"
    fields_desc = [
        ByteEnumField("Function", 0x1a, S7_JB_Function),
        XByteField("FunctionStatus", 0x00),
        StrFixedLenField("UnKnown1", "\x00\x00\x00\x00\x00\x00", length=6),
        FieldLenField("FileNameLength", None, fmt="B", length_of="Filename", adjust=lambda pkt, x: x),
        StrLenField("Filename", "", length_from=lambda p: p.FileNameLength)
    ]


class S7RequestDownloadFileReq(Packet):
    name = "S7_Request_Download_File_Req"
    fields_desc = [
        XByteField("ProtocolId", 0x32),
        ByteEnumField("ROSCTR", 0x01, S7_PDU_Type),
        XShortField("RedundancyId", 0x0000),
        LEShortField("PDUR", 0x0d00),
        FieldLenField("ParameterLength", None, length_of="Parameters", adjust=lambda pkt, x: x),
        XShortField("DataLength", None),
        PacketLenField(
            "Parameters",
            S7RequestDownloadFileParameterReq(),
            S7RequestDownloadFileParameterReq,
            length_from=lambda x: x.ParameterLength
        )
    ]


class S7DownloadFileDataRsp(Packet):
    name = "S7_DownloadBlock_Data_Rsp"
    fields_desc = [
        FieldLenField("DataLength", None, length_of="Data", adjust=lambda pkt, x:x),
        XShortField("UnKnown1", 0x00fb),
        StrLenField("Data", "\x00", length_from=lambda x: x.DataLength)
    ]


class S7DownloadFileParameterRsp(Packet):
    name = "S7_Download_File_Parameter_Rsp"
    fields_desc = [
        ByteEnumField("Function", 0x1b, S7_JB_Function),
        BitField("Unused", 0, 6),
        FlagsField("FunctionStatus", 0, 2, S7_Function_Status)
    ]


class S7DownloadFileRsp(Packet):
    name = "S7_Download_File_Rsp"
    fields_desc = [
        XByteField("ProtocolId", 0x32),
        ByteEnumField("ROSCTR", 0x03, S7_PDU_Type),
        XShortField("RedundancyId", 0x0000),
        XShortField("PDUR", 0x00d0),
        FieldLenField("ParameterLength", None, fmt="H", length_of="Parameters", adjust=lambda pkt, x: x),
        FieldLenField("DataLength", None, fmt="H", length_of="Data", adjust=lambda pkt, x: x),
        ByteEnumField("ErrorClass", 0x00, S7_Error_Class),
        XByteField("ErrorCode", 0x00),
        PacketLenField(
            "Parameters",
            S7DownloadFileParameterRsp(),
            S7DownloadFileParameterRsp,
            length_from=lambda x: x.ParameterLength
        ),
        PacketLenField(
            "Data",
            S7DownloadFileDataRsp(),
            S7DownloadFileDataRsp,
            length_from=lambda x: x.DataLength
        )
    ]


class S7DownloadFileEndFParameterRsp(Packet):
    name = "S7_Download_File_End_Parameter_Rsp"
    fields_desc = [
        ByteEnumField("Function", 0x1c, S7_JB_Function),
    ]


class S7DownloadFileEndRsp(Packet):
    name = "S7_Download_File_End_Rsp"
    fields_desc = [
        XByteField("ProtocolId", 0x32),
        ByteEnumField("ROSCTR", 0x03, S7_PDU_Type),
        XShortField("RedundancyId", 0x0000),
        XShortField("PDUR", 0x00d0),
        FieldLenField("ParameterLength", None, fmt="H", length_of="Parameters", adjust=lambda pkt, x: x),
        XShortField("DataLength", 0),
        ByteEnumField("ErrorClass", 0x00, S7_Error_Class),
        XByteField("ErrorCode", 0x00),
        PacketLenField(
            "Parameters",
            S7DownloadFileEndFParameterRsp(),
            S7DownloadFileEndFParameterRsp,
            length_from=lambda x: x.ParameterLength
        )
    ]


##############
class S7DeleteBlockParameterReq(Packet):
    name = "S7_DeleteBlock_Parameter_Req"
    fields_desc = [
        ByteEnumField("Function", 0x28, S7_JB_Function),
        StrFixedLenField("Unknown1", "\x00\x00\x00\x00\x00\x00\xfd", length=7),
        XShortField("Length1", 0x000a),
        XByteField("BlockCount", 0x01),
        XByteField("Unknown2", 0x00),
        XByteField("Unknown3", 0x30),
        ByteEnumField("BlockType", 0x43, S7_Block_Type),
        StrFixedLenField("BlockNum", "00000", length=5),
        XByteField("DstFileSystem", 0x42),
        FieldLenField("StringLength", None, fmt="B", length_of="PI", adjust=lambda pkt, x: x),
        StrLenField("PI", "_DELE", length_from=lambda p: p.StringLength)
    ]


class S7DeleteBlockReq(Packet):
    name = "S7_DeleteBlock_Req"
    fields_desc = [
        XByteField("ProtocolId", 0x32),
        ByteEnumField("ROSCTR", 0x01, S7_PDU_Type),
        XShortField("RedundancyId", 0x0000),
        XShortField("PDUR", 0x0c00),
        FieldLenField("ParameterLength", None, fmt="H", length_of="Parameters", adjust=lambda pkt, x: x),
        XShortField("DataLength", 0),
        PacketLenField(
            "Parameters",
            S7DeleteBlockParameterReq(),
            S7DeleteBlockParameterReq,
            length_from=lambda x: x.ParameterLength)
    ]


###########Upload-Block-start################

class S7RequestUploadBlockParameterReq(Packet):
    name = "S7_RequestUploadBlock_Parameter_Req"
    fields_desc = [
        ByteEnumField("Function", 0x1d, S7_JB_Function),
        StrFixedLenField("Unknow1", "\x00\x00\x00\x00\x00\x00\x00", length=7),
        XByteField("Lenth1", 0x09),
        XByteField("FileId", 0x5f),
        XByteField("Unknow2", 0x30),
        ByteEnumField("BlockType", 0x43, S7_Block_Type),
        StrFixedLenField("BlockNum", "00000", length=5),
        XByteField("DstFileSystem", 0x41)
    ]


class S7RequestUploadBlockReq(Packet):
    name = "S7_RequestUploadBlock_Req"
    fields_desc = [
        XByteField("ProtocolId", 0x32),
        ByteEnumField("ROSCTR", 0x01, S7_PDU_Type),
        XShortField("RedundancyId", 0x0000),
        LEShortField("PDUR", 0x0100),
        FieldLenField("ParameterLength", None, fmt="H", length_of="Parameters", adjust=lambda pkt, x: x),
        XShortField("DataLength", 0),
        PacketLenField(
            "Parameters",
            S7RequestUploadBlockParameterReq(),
            S7RequestUploadBlockParameterReq,
            length_from=lambda x: x.ParameterLength
        )
    ]


class S7UploadBlockParameterReq(Packet):
    name = "S7_UploadBlock_Parameter_Req"
    fields_desc = [
        ByteEnumField("Function", 0x1e, S7_JB_Function),
        BitField("Unused", 0, 6),
        FlagsField("FunctionStatus", 0, 2, S7_Function_Status),
        XShortField("Unknown1", 0x0000),
        IntField("UploadId", 0x00000000)
    ]


class S7UploadBlockReq(Packet):
    name = "S7_UploadBlock_Req"
    fields_desc = [
        XByteField("ProtocolId", 0x32),
        ByteEnumField("ROSCTR", 0x01, S7_PDU_Type),
        XShortField("RedundancyId", 0x0000),
        LEShortField("PDUR", 0x0200),
        FieldLenField("ParameterLength", None, fmt="H", length_of="Parameters", adjust=lambda pkt, x: x),
        XShortField("DataLength", 0),
        PacketLenField(
            "Parameters",
            S7UploadBlockParameterReq(),
            S7UploadBlockParameterReq,
            length_from=lambda x: x.ParameterLength
        )
    ]


class S7UploadBlockEndParameterReq(Packet):
    name = "S7_UploadBlockEnd_Parameter_Req"
    fields_desc = [
        ByteEnumField("Function", 0x1f, S7_JB_Function),
        BitField("Unused", 0, 6),
        FlagsField("FunctionStatus", 0, 2, S7_Function_Status),
        XShortEnumField("ErrorCode", 0x0000, S7_Error_Class),
        StrFixedLenField("Unknown1", "\x00\x00\x00\x00", length=4)
    ]


class S7UploadBlockEndReq(Packet):
    name = "S7_UploadBlockEnd_Req"
    fields_desc = [
        XByteField("ProtocolId", 0x32),
        ByteEnumField("ROSCTR", 0x01, S7_PDU_Type),
        XShortField("RedundancyId", 0x0000),
        LEShortField("PDUR", 0x0300),
        FieldLenField("ParameterLength", None, fmt="H", length_of="Parameters", adjust=lambda pkt, x: x),
        XShortField("DataLength", 0),
        PacketLenField(
            "Parameters",
            S7UploadBlockEndParameterReq(),
            S7UploadBlockEndParameterReq,
            length_from=lambda x: x.ParameterLength
        )
    ]


class S7RequestUploadBlockParameterRsp(Packet):
    name = "S7_RequestUploadBlock_Parameter_Rsp"
    fields_desc = [
        ByteEnumField("Function", 0x1d, S7_JB_Function),
        BitField("Unused", 0, 6),
        FlagsField("FunctionStatus", 0, 2, S7_Function_Status),
        StrFixedLenField("Unknown1", "\x01\x00", length=2),
        IntField("UploadId", 0x00000000),
        FieldLenField("BlockLengthStringLength", None, length_of="BlockLength", adjust=lambda pkt, x: x),
        StrLenField(
            "BlockLength",
            "\x30\x30\x30\x30\x30\x30\x30",
            length_from=lambda x: x.BlockLengthStringLength
        )
    ]


class S7RequestUploadBlockRsp(Packet):
    name = "S7_RequestUploadBlock_Rsp"
    fields_desc = [
        XByteField("ProtocolId", 0x32),
        ByteEnumField("ROSCTR", 0x03, S7_PDU_Type),
        XShortField("RedundancyId", 0x0000),
        LEShortField("PDUR", 0x0100),
        FieldLenField("ParameterLength", None, fmt="H", length_of="Parameters", adjust=lambda pkt, x: x),
        XShortField("DataLength", 0),
        ByteEnumField("ErrorClass", 0x00, S7_Error_Class),
        XByteField("ErrorCode", 0x00),
        PacketLenField(
            "Parameters",
            S7RequestUploadBlockParameterRsp(),
            S7RequestUploadBlockParameterRsp,
            length_from=lambda x: x.ParameterLength
        )
    ]


class S7UploadBlockDataRsp(Packet):
    name = "S7_UploadBlock_Data_Rsp"
    fields_desc = [
        FieldLenField("DataLength", None, length_of="Data", adjust=lambda pkt, x:x),
        XShortField("Unknow1", 0x00fb),
        StrLenField("Data", "\x00", length_from=lambda x: x.DataLength)
    ]


class S7UploadBlockParameterRsp(Packet):
    name = "S7_UploadBlock_Parameter_Rsp"
    fields_desc = [
        ByteEnumField("Function", 0x1e, S7_JB_Function),
        BitField("Unused", 0, 6),
        FlagsField("FunctionStatus", 0, 2, S7_Function_Status)
    ]


class S7UploadBlockRsp(Packet):
    name = "S7_UploadBlock_Rsp"
    fields_desc = [
        XByteField("ProtocolId", 0x32),
        ByteEnumField("ROSCTR", 0x03, S7_PDU_Type),
        XShortField("RedundancyId", 0x0000),
        LEShortField("PDUR", 0x00d0),
        FieldLenField("ParameterLength", None, fmt="H", length_of="Parameters", adjust=lambda pkt, x: x),
        FieldLenField("DataLength", None, fmt="H", length_of="Data", adjust=lambda pkt, x: x),
        ByteEnumField("ErrorClass", 0x00, S7_Error_Class),
        XByteField("ErrorCode", 0x00),
        PacketLenField(
            "Parameters",
            S7UploadBlockParameterRsp(),
            S7UploadBlockParameterRsp,
            length_from=lambda x: x.ParameterLength
        ),
        PacketLenField(
            "Data",
            S7UploadBlockDataRsp(),
            S7UploadBlockDataRsp,
            length_from=lambda x: x.DataLength
        )
    ]


class S7UploadBlockEndParameterRsp(Packet):
    name = "S7_UploadBlockEnd_Parameter_Rsp"
    fields_desc = [
        ByteEnumField("Function", 0x1f, S7_JB_Function)
    ]


class S7UploadBlockEndRsp(Packet):
    name = "S7_UploadBlockEnd_Rsp"
    fields_desc = [
        XByteField("ProtocolId", 0x32),
        ByteEnumField("ROSCTR", 0x03, S7_PDU_Type),
        XShortField("RedundancyId", 0x0000),
        LEShortField("PDUR", 0x0300),
        FieldLenField("ParameterLength", None, fmt="H", length_of="Parameters", adjust=lambda pkt, x: x),
        XShortField("DataLength", 0),
        ByteEnumField("ErrorClass", 0x00, S7_Error_Class),
        XByteField("ErrorCode", 0x00),
        PacketLenField(
            "Parameters",
            S7UploadBlockEndParameterRsp(),
            S7UploadBlockEndParameterRsp,
            length_from=lambda x: x.ParameterLength
        )
    ]


##################end#######################

class S7PasswordDataReq(Packet):
    name = "S7_Password_Data_TPDU"
    fields_desc = [
        ByteEnumField("ReturnCode", 0xff, S7_Return_Code),
        ByteEnumField("TransportSize", 0x09, S7_Transport_Size),
        FieldLenField("DataLength", None, fmt="H", length_of="Data", adjust=lambda pkt, x: x),
        StrLenField("Data", "\x00" * 8, length_from="DataLength")
    ]


class S7PasswordParameterReq(Packet):
    name = "S7_Password_Parameter_TPDU"
    fields_desc = [
        StrFixedLenField("ParameterHead", "\x00\x01\x12", length=3),
        XByteField("ParameterLength", 0x04),
        XByteField("Unknow", 0x11),
        BitEnumField("Type", 4, 4, S7_UD_Parameter_Type),
        BitEnumField("FunctionGroup", 5, 4, S7_UD_Function_Group),
        XByteField("SubFunction", 0x01),
        XByteField("Seq", 0x00)
    ]


class S7PasswordReq(Packet):
    name = "S7_Password_TPDU"
    fields_desc = [
        XByteField("ProtocolId", 0x32),
        ByteEnumField("ROSCTR", 0x07, S7_PDU_Type),
        XShortField("RedundancyId", 0x0000),
        LEShortField("PDUR", 0x1e00),
        XShortField("ParameterLength", 8),
        XShortField("DataLength", 12),
        PacketLenField(
            "Parameters",
            S7PasswordParameterReq(),
            S7PasswordParameterReq,
            length_from=lambda x: x.ParameterLength
        ),
        PacketField(
            "Data",
            S7PasswordDataReq(),
            S7PasswordDataReq
        )
    ]


class S7CleanSessionDataReq(Packet):
    name = "S7_Clean_Session_Data_TPDU"
    fields_desc = [
        ByteEnumField("ReturnCode", 0x0a, S7_Return_Code),
        ByteEnumField("TransportSize", 0x00, S7_Transport_Size),
        XShortField("Length", 0x0000)
    ]


class S7CleanSessionParameterReq(Packet):
    name = "S7_Clean_Session_Parameter_Req"
    fields_desc = [
        StrFixedLenField("ParameterHead", "\x00\x01\x12", length=3),
        XByteField("ParameterLength", 0x04),
        XByteField("Unknow", 0x11),
        BitEnumField("Type", 4, 4, S7_UD_Parameter_Type),
        BitEnumField("FunctionGroup", 5, 4, S7_UD_Function_Group),
        XByteField("SubFunction", 0x02),
        XByteField("Seq", 0x00)
    ]


class S7CleanSessionReq(Packet):
    name = "S7_PLC_Password_TPDU"
    fields_desc = [
        XByteField("ProtocolId", 0x32),
        ByteEnumField("ROSCTR", 0x07, S7_PDU_Type),
        XShortField("RedundancyId", 0x0000),
        LEShortField("PDUR", 0x1e00),
        FieldLenField("ParameterLength", None, fmt="H", length_of="Parameters", adjust=lambda pkt, x: x),
        FieldLenField("DataLength", None, fmt="H", length_of="Data", adjust=lambda pkt, x: x),
        PacketLenField(
            "Parameters",
            S7CleanSessionParameterReq(),
            S7CleanSessionParameterReq,
            length_from=lambda x: x.ParameterLength
        ),
        PacketField(
            "Data",
            S7CleanSessionDataReq(),
            S7CleanSessionDataReq
        )
    ]


class S7StopCpuParameterReq(Packet):
    name = "S7_Stop_Cpu_Parameter_Req"
    fields_desc = [
        ByteEnumField("Function", 0x29, S7_JB_Function),
        StrFixedLenField("Unknown1", "\x00\x00\x00\x00\x00", length=5),
        FieldLenField("StringLength", None, fmt="B", length_of="PI", adjust=lambda pkt, x: x),
        StrLenField("PI", "P_PROGRAM", length_from=lambda p: p.StringLength)
    ]


class S7StopCpuReq(Packet):
    name = "S7_Stop_Cpu_Req"
    fields_desc = [
        XByteField("ProtocolId", 0x32),
        ByteEnumField("ROSCTR", 0x01, S7_PDU_Type),
        XShortField("RedundancyId", 0x0000),
        LEShortField("PDUR", 0x1e00),
        FieldLenField("ParameterLength", None, fmt="H", length_of="Parameters", adjust=lambda pkt, x: x),
        XShortField("DataLength", 0),
        PacketLenField(
            "Parameters",
            S7StopCpuParameterReq(),
            S7StopCpuParameterReq,
            length_from=lambda x: x.ParameterLength
        ),
    ]


class S7StopCpuParameterRsp(Packet):
    name = "S7_Stop_Cpu_Parameter_Rsp"
    fields_desc = [
        ByteEnumField("Function", 0x29, S7_JB_Function),
        ByteField("ParameterData", 0x04),
    ]


class S7StopCpuRsp(Packet):
    name = "S7_Stop_Cpu_Rsp"
    fields_desc = [
        XByteField("ProtocolId", 0x32),
        ByteEnumField("ROSCTR", 0x03, S7_PDU_Type),
        XShortField("RedundancyId", 0x0000),
        LEShortField("PDUR", 0x1e00),
        FieldLenField("ParameterLength", None, fmt="H", length_of="Parameters", adjust=lambda pkt, x: x),
        XShortField("DataLength", 0),
        ByteEnumField("ErrorClass", 0x00, S7_Error_Class),
        XByteField("ErrorCode", 0x00),
        PacketLenField(
            "Parameters",
            None,
            S7StopCpuParameterRsp,
            length_from=lambda x: x.ParameterLength
        ),
    ]


###
class S7PIServiceParameterReq(Packet):
    name = "S7_PI_Service_Parameter_Req"
    fields_desc = [
        ByteEnumField("Function", 0x28, S7_JB_Function),
        StrFixedLenField("Unknown1", "\x00\x00\x00\x00\x00\x00\xfd", length=7),
        FieldLenField("ParameterBlockLength", None, fmt="H", length_of="ParameterBlock", adjust=lambda pkt, x: x),
        StrLenField("ParameterBlock", "", length_from=lambda p: p.ParameterBlockLength),
        FieldLenField("StringLength", None, fmt="B", length_of="PI", adjust=lambda pkt, x: x),
        StrLenField("PI", "P_PROGRAM", length_from=lambda p: p.StringLength)
    ]


class S7PIServiceReq(Packet):
    name = "S7_Start_Cpu_Req"
    fields_desc = [
        XByteField("ProtocolId", 0x32),
        ByteEnumField("ROSCTR", 0x01, S7_PDU_Type),
        XShortField("RedundancyId", 0x0000),
        LEShortField("PDUR", 0x1e00),
        FieldLenField("ParameterLength", None, fmt="H", length_of="Parameters", adjust=lambda pkt, x: x),
        XShortField("DataLength", 0),
        PacketLenField(
            "Parameters",
            S7PIServiceParameterReq(),
            S7PIServiceParameterReq,
            length_from=lambda x: x.ParameterLength
        ),
    ]


class S7PIServiceParameterRsp(Packet):
    name = "S7_PI_Service_Parameter_Rsp"
    fields_desc = [
        ByteEnumField("Function", 0x28, S7_JB_Function),
    ]


class S7PIServiceRsp(Packet):
    name = "S7_PI_Service_Rsp"
    fields_desc = [
        XByteField("ProtocolId", 0x32),
        ByteEnumField("ROSCTR", 0x03, S7_PDU_Type),
        XShortField("RedundancyId", 0x0000),
        LEShortField("PDUR", 0x1e00),
        FieldLenField("ParameterLength", None, fmt="H", length_of="Parameters", adjust=lambda pkt, x: x),
        XShortField("DataLength", 0),
        ByteEnumField("ErrorClass", 0x00, S7_Error_Class),
        XByteField("ErrorCode", 0x00),
        PacketLenField(
            "Parameters",
            None,
            S7PIServiceParameterRsp,
            length_from=lambda x: x.ParameterLength
        ),
    ]


# TODO: this not work with StreamSocket
bind_layers(TCP, TpktReq, dport=102)
bind_layers(TCP, TpktRsp, sport=102)
