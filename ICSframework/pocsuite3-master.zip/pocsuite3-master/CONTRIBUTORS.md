hysia <s1@seebug.org>
* for contributing core code

badcode <s1@seebug.org>
* for contributing core code

cc <s1@seebug.org>
* for contributing core code

w7ay <https://github.com/boy-hack>
* for contributing core code

phithon <root(at)leavesongs.com>
* for suggesting a couple of features

longofo
* for contributing http server module

Ro0tk1t <https://github.com/Ro0tk1t>
* for contributing multi-ip multi-poc execution features
* fix some issues

hawoosec <hanwu@protonmail.com>
* for reporting a bug
* for contributing a minor patch
* bugfix invalid client
* for contributing `set lhost index`

Explorer1092 <https://github.com/Explorer1092>
* update usage.md

gsfish <https://github.com/gsfish>
* good first issue #85
* repair the custom cookie anomalies

Becivells <https://github.com/Becivells>
* bugfix shodan api
* for contributing fofa api
* for contributing random user-agent switch