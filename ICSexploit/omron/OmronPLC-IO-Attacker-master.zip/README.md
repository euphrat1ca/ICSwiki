# OmronPLC-IO-Attacker
# Warning:will affect the real plc system operation!!!
#
Forced set CIO data and Control Omron PLC CPU