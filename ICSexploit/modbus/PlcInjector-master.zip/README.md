# PlcInjector
Modbus stager in assembly and some scripts to upload/download data to the holding register of a PLC. More info:

http://www.shelliscoming.com/2016/12/modbus-stager-using-plcs-as.html
