# DNP3 PCAPS

These pcaps were recorded using various DNP3 software packages for the purposes of writing tests for a firewall parser. 

They contain a very large portion of the protocol in terms of function codes and objects. They include more obscure parts of the protocol 
such as file transfer, datasets, and secure authentication.
