PROFINET-RT.pcap
  Source: https://www.cloudshark.org/captures/76038eaa4a3b
