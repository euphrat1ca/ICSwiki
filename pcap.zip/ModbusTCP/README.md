ModbusTCP.pcap
  Source: https://www.cloudshark.org/captures/76038eaa4a3b
  Modbus Challenges:
    Which IP address is the master on?
    How many slaves is the master talking to?
    Is the master writing any data to the slaves?
    Does the traffic spike in the middle related to modbus?