Source: https://www.cloudshark.org/captures/76038eaa4a3b

Has Modbus, Profinet, EtherNet/IP-CIP, and S7COMM

Look at IT traffic to identify the company
